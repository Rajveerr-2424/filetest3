// Russian Roulette DApp - Main Application Logic
// Complete game orchestration with blockchain integration and 3D graphics

class RussianRouletteDApp {
  constructor() {
    // Core systems
    this.soundManager = new SoundManager();
    this.animationManager = new AnimationManager();
    this.randomGenerator = new SecureRandomGenerator();
    this.achievementManager = new AchievementManager();
    this.gameStats = new GameStats();
    
    // Blockchain components
    this.walletManager = window.walletManager;
    this.gameContract = window.gameContract;
    this.transactionMonitor = window.transactionMonitor;
    
    // 3D components
    this.revolverRenderer = null;
    this.playerSprite = null;
    this.botSprite = null;
    this.particleManager = null;
    
    // Game state
    this.currentState = GAME_STATES.DISCONNECTED;
    this.currentPage = 'homePage';
    this.roundInProgress = false;
    this.currentRound = 1;
    this.playerHealth = 100;
    this.botHealth = 100;
    this.liveChamber = null;
    this.lastAction = null;
    
    // Performance monitoring
    window.gamePerformance.mark('app_init_start');
    
    this.init();
  }
  
  async init() {
    try {
      Logger.log('Initializing Russian Roulette DApp');
      
      // Setup event listeners
      this.setupEventListeners();
      this.setupBlockchainEventListeners();
      
      // Setup achievement system
      this.achievementManager.onAchievementUnlocked = (achievement) => {
        this.handleAchievementUnlocked(achievement);
      };
      
      // Initialize UI
      this.updateUI();
      this.updateNetworkStatus();
      
      // Hide loading screen
      setTimeout(() => {
        DOMUtils.hideLoading();
      }, 1500);
      
      Logger.log('DApp initialized successfully');
      window.gamePerformance.measure('app_init', 'app_init_start');
      
    } catch (error) {
      Logger.error('Failed to initialize DApp', error);
      DOMUtils.hideLoading();
    }
  }
  
  setupEventListeners() {
    // Navigation
    document.getElementById('navHome')?.addEventListener('click', () => this.showPage('homePage'));
    document.getElementById('navGame')?.addEventListener('click', () => this.showPage('gamePage'));
    document.getElementById('navLeaderboard')?.addEventListener('click', () => this.showPage('leaderboardPage'));
    
    // Wallet actions
    document.getElementById('connectWallet')?.addEventListener('click', () => this.connectWallet());
    document.getElementById('enterGame')?.addEventListener('click', () => this.enterGame());
    
    // Game actions
    document.getElementById('fireAtSelf')?.addEventListener('click', () => this.playerAction(PLAYER_ACTIONS.FIRE_AT_SELF));
    document.getElementById('fireAtBot')?.addEventListener('click', () => this.playerAction(PLAYER_ACTIONS.FIRE_AT_BOT));
    document.getElementById('exitGame')?.addEventListener('click', () => this.exitGame());
    
    // Sound toggle
    document.getElementById('toggleSound')?.addEventListener('click', () => this.toggleSound());
    
    // Modal actions
    document.getElementById('continueButton')?.addEventListener('click', () => this.continueAfterResult());
    
    // Modal overlay clicks (close modals)
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
          overlay.parentElement.classList.remove('show');
        }
      });
    });
    
    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => this.handleKeyPress(e));
    
    Logger.log('Event listeners setup complete');
  }
  
  setupBlockchainEventListeners() {
    // Wallet events
    this.walletManager.on('connected', (data) => {
      Logger.log('Wallet connected', data);
      this.setState(GAME_STATES.WALLET_CONNECTED);
      this.updateWalletUI(data);
      this.enableGameAccess();
    });
    
    this.walletManager.on('disconnected', () => {
      Logger.log('Wallet disconnected');
      this.setState(GAME_STATES.DISCONNECTED);
      this.disableGameAccess();
      this.updateWalletUI(null);
    });
    
    this.walletManager.on('accountChanged', (data) => {
      Logger.log('Account changed', data);
      this.updateWalletUI(data);
      this.gameStats.loadFromStorage(); // Reload stats for new account
      this.updateUI();
    });
    
    this.walletManager.on('networkChanged', (data) => {
      Logger.log('Network changed', data);
      this.updateNetworkStatus();
    });
    
    this.walletManager.on('balanceUpdated', (data) => {
      this.updateWalletUI(data);
    });
    
    // Contract events
    this.gameContract.on('RoundRequested', (data) => {
      Logger.log('Round requested on blockchain', data);
      this.handleRoundRequested(data);
    });
    
    this.gameContract.on('RoundSettled', (data) => {
      Logger.log('Round settled on blockchain', data);
      this.handleRoundSettled(data);
    });
  }
  
  handleKeyPress(e) {
    if (this.currentPage === 'gamePage' && this.currentState === GAME_STATES.WAITING_FOR_CHOICE) {
      switch (e.code) {
        case 'Digit1':
        case 'KeyS':
          e.preventDefault();
          this.playerAction(PLAYER_ACTIONS.FIRE_AT_SELF);
          break;
        case 'Digit2':
        case 'KeyB':
          e.preventDefault();
          this.playerAction(PLAYER_ACTIONS.FIRE_AT_BOT);
          break;
      }
    }
  }
  
  async connectWallet() {
    try {
      this.setState(GAME_STATES.CONNECTING_WALLET);
      const connectionInfo = await this.walletManager.connect();
      
      // Play success sound
      this.soundManager.play('victory');
      
      Logger.log('Wallet connection successful', connectionInfo);
      
    } catch (error) {
      Logger.error('Wallet connection failed', error);
      
      // Show user-friendly error
      const message = BlockchainErrorHandler.handle(error);
      this.showErrorMessage(message);
      
      this.setState(GAME_STATES.DISCONNECTED);
    }
  }
  
  enableGameAccess() {
    const enterGameBtn = document.getElementById('enterGame');
    const navGameBtn = document.getElementById('navGame');
    
    if (enterGameBtn) {
      enterGameBtn.disabled = false;
      enterGameBtn.textContent = 'Enter Game';
    }
    
    if (navGameBtn) {
      navGameBtn.disabled = false;
    }
  }
  
  disableGameAccess() {
    const enterGameBtn = document.getElementById('enterGame');
    const navGameBtn = document.getElementById('navGame');
    
    if (enterGameBtn) {
      enterGameBtn.disabled = true;
      enterGameBtn.textContent = 'Connect Wallet First';
    }
    
    if (navGameBtn) {
      navGameBtn.disabled = true;
    }
  }
  
  updateWalletUI(data) {
    const walletInfo = document.getElementById('walletInfo');
    const connectBtn = document.getElementById('connectWallet');
    
    if (data && data.address) {
      // Connected state
      if (walletInfo) {
        walletInfo.innerHTML = `
          <div class="text-xs text-green-500">Connected</div>
          <div class="text-xs font-mono">${BlockchainUtils.formatAddress(data.address)}</div>
          ${data.balance ? `<div class="text-xs">${BlockchainUtils.formatBalance(data.balance)} tFIL</div>` : ''}
        `;
      }
      
      if (connectBtn) {
        connectBtn.innerHTML = `
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
          </svg>
          Connected
        `;
        connectBtn.classList.remove('btn-primary');
        connectBtn.classList.add('btn-secondary');
        connectBtn.disabled = true;
      }
    } else {
      // Disconnected state
      if (walletInfo) {
        walletInfo.innerHTML = '';
      }
      
      if (connectBtn) {
        connectBtn.innerHTML = `
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 0h10a2 2 0 002-2v-3a2 2 0 00-2-2H9a2 2 0 00-2 2v3a2 2 0 002 2z"/>
          </svg>
          Connect Wallet
        `;
        connectBtn.classList.remove('btn-secondary');
        connectBtn.classList.add('btn-primary');
        connectBtn.disabled = false;
      }
    }
  }
  
  updateNetworkStatus() {
    const connection = this.walletManager.getConnectionInfo();
    DOMUtils.updateNetworkStatus(
      connection.connected && connection.networkCorrect,
      connection.network
    );
  }
  
  async enterGame() {
    if (!this.walletManager.connected) {
      this.showErrorMessage('Please connect your wallet first');
      return;
    }
    
    this.showPage('gamePage');
    await this.initializeGame();
  }
  
  async initializeGame() {
    try {
      this.setState(GAME_STATES.INITIALIZING_GAME);
      DOMUtils.showLoading('Initializing 3D engine...');
      
      // Initialize 3D components
      await this.init3DEngine();
      
      // Initialize character sprites
      this.playerSprite = new CharacterSprite('playerSprite');
      this.botSprite = new CharacterSprite('botSprite');
      
      // Reset game state
      this.resetGameState();
      
      // Start first round
      await this.startNewRound();
      
      Logger.log('Game initialized successfully');
      
    } catch (error) {
      Logger.error('Failed to initialize game', error);
      this.showErrorMessage('Failed to initialize game. Please try again.');
      this.showPage('homePage');
    } finally {
      DOMUtils.hideLoading();
    }
  }
  
  async init3DEngine() {
    // Dispose existing renderer
    if (this.revolverRenderer) {
      this.revolverRenderer.dispose();
    }
    
    // Create new 3D renderer
    this.revolverRenderer = new RevolverRenderer('revolverContainer');
    
    // Initialize particle system if Three.js is available
    if (window.threeJsAvailable && this.revolverRenderer.scene) {
      this.particleManager = new ParticleEffectManager(this.revolverRenderer.scene);
    }
    
    // Wait for initialization
    await this.delay(500);
  }
  
  resetGameState() {
    this.currentRound = 1;
    this.playerHealth = 100;
    this.botHealth = 100;
    this.roundInProgress = false;
    this.liveChamber = null;
    this.lastAction = null;
    
    // Update character sprites
    if (this.playerSprite) {
      this.playerSprite.updateHealth(100);
      this.playerSprite.setActive(false);
    }
    
    if (this.botSprite) {
      this.botSprite.updateHealth(100);
      this.botSprite.setActive(false);
    }
    
    // Reset revolver
    if (this.revolverRenderer) {
      this.revolverRenderer.resetChambers();
    }
    
    this.updateUI();
  }
  
  async startNewRound() {
    this.setState(GAME_STATES.INITIALIZING_GAME);
    this.updateRoundStatus(`Round ${this.currentRound} - Preparing chamber...`);
    
    // Generate live chamber position using secure random
    this.liveChamber = await this.randomGenerator.generateSecureRandom(0, 5, { fastMode: false });
    
    Logger.log(`Round ${this.currentRound} started, live chamber: ${this.liveChamber}`);
    
    // Reset chamber display
    this.updateChamberDisplay();
    
    // Set game state to waiting
    this.setState(GAME_STATES.WAITING_FOR_CHOICE);
    this.updateRoundStatus('Choose your action');
    
    // Enable action buttons
    this.setActionButtonsEnabled(true);
  }
  
  async playerAction(action) {
    if (this.roundInProgress || this.currentState !== GAME_STATES.WAITING_FOR_CHOICE) {
      return;
    }
    
    this.roundInProgress = true;
    this.lastAction = action;
    this.setActionButtonsEnabled(false);
    
    try {
      // Submit to blockchain
      this.setState(GAME_STATES.SPINNING_REVOLVER);
      this.updateRoundStatus('Submitting to blockchain...');
      
      const target = action === PLAYER_ACTIONS.FIRE_AT_SELF ? 0 : 1;
      const result = await this.gameContract.playRound(target);
      
      Logger.log('Round submitted to blockchain', result);
      
    } catch (error) {
      Logger.error('Failed to submit round', error);
      this.showErrorMessage(BlockchainErrorHandler.handle(error));
      
      // Reset round state
      this.roundInProgress = false;
      this.setState(GAME_STATES.WAITING_FOR_CHOICE);
      this.updateRoundStatus('Choose your action');
      this.setActionButtonsEnabled(true);
    }
  }
  
  async handleRoundRequested(data) {
    this.updateRoundStatus('Spinning revolver...');
    
    // Play spin sound and animation
    this.soundManager.play('spin');
    
    if (this.revolverRenderer) {
      await this.revolverRenderer.spinRevolver(3000);
    }
    
    this.updateRoundStatus('Waiting for blockchain confirmation...');
  }
  
  async handleRoundSettled(data) {
    const { chamberPosition, survived, killedBot, scoreChange } = data;
    
    Logger.log('Processing round result', data);
    
    this.setState(GAME_STATES.FIRING);
    this.updateRoundStatus('Firing...');
    
    // Set active character
    const isPlayerAction = this.lastAction === PLAYER_ACTIONS.FIRE_AT_SELF;
    if (isPlayerAction && this.playerSprite) {
      this.playerSprite.setActive(true);
    } else if (!isPlayerAction && this.botSprite) {
      this.botSprite.setActive(true);
    }
    
    // Fire animation
    if (this.revolverRenderer) {
      this.revolverRenderer.highlightChamber(chamberPosition);
      await this.revolverRenderer.fireBullet(chamberPosition);
    }
    
    // Play gunshot sound
    this.soundManager.play('gunshot');
    
    // Character animation
    if (isPlayerAction && this.playerSprite) {
      await this.playerSprite.fire();
    }
    
    // Process outcome
    await this.processRoundOutcome(survived, killedBot, scoreChange, isPlayerAction);
    
    // Update chamber display
    this.updateChamberDisplay(chamberPosition, !survived);
    
    // Update game stats
    this.gameStats.recordRound(this.lastAction, survived, killedBot);
    
    // Check achievements
    this.achievementManager.checkAchievements(this.gameStats.getStats());
    
    // Update UI
    this.updateUI();
    
    // Show result modal
    this.showResultModal(survived, killedBot, scoreChange, isPlayerAction);
  }
  
  async processRoundOutcome(survived, killedBot, scoreChange, isPlayerAction) {
    this.setState(GAME_STATES.SHOWING_RESULT);
    
    if (survived) {
      if (killedBot) {
        // Bot was eliminated
        this.botHealth = 0;
        if (this.botSprite) {
          this.botSprite.updateHealth(0);
          await this.botSprite.die();
        }
        
        // Celebration effects
        if (this.playerSprite) {
          await this.playerSprite.celebrate();
        }
        
        this.soundManager.play('victory');
        
        // Particle effects
        if (this.particleManager) {
          this.particleManager.createExplosion(new THREE.Vector3(2, 0, 0), 0xff4444);
        }
      } else {
        // Blank chamber - survived
        this.soundManager.play('victory');
        
        if (this.playerSprite) {
          await this.playerSprite.celebrate();
        }
      }
    } else {
      // Player died
      this.playerHealth = 0;
      
      if (this.playerSprite) {
        this.playerSprite.updateHealth(0);
        await this.playerSprite.die();
      }
      
      this.soundManager.play('death');
      
      // Blood effects
      if (this.particleManager) {
        this.particleManager.createBloodSpatter(new THREE.Vector3(-2, 0, 0));
      }
    }
    
    // Clear active states
    if (this.playerSprite) this.playerSprite.setActive(false);
    if (this.botSprite) this.botSprite.setActive(false);
  }
  
  showResultModal(survived, killedBot, scoreChange, isPlayerAction) {
    let icon, title, message;
    
    if (survived) {
      if (killedBot) {
        icon = '🎯';
        title = 'Elimination!';
        message = 'You eliminated the bot!';
      } else {
        icon = '😅';
        title = 'Lucky Shot!';
        message = 'Blank chamber - you survived!';
      }
    } else {
      icon = '💀';
      title = 'Game Over';
      message = isPlayerAction ? 'You hit the live bullet!' : 'The bot got you!';
    }
    
    // Update modal content
    DOMUtils.updateElement('resultIcon', icon);
    DOMUtils.updateElement('resultTitle', title);
    DOMUtils.updateElement('resultMessage', message);
    
    // Show score change
    const scoreElement = document.getElementById('scoreChange');
    if (scoreElement) {
      scoreElement.textContent = `${scoreChange > 0 ? '+' : ''}${scoreChange} points`;
      scoreElement.className = `score-change ${scoreChange >= 0 ? 'positive' : 'negative'}`;
    }
    
    // Update continue button
    const continueBtn = document.getElementById('continueButton');
    if (continueBtn) {
      if (this.playerHealth <= 0 || this.botHealth <= 0) {
        continueBtn.textContent = 'New Game';
      } else {
        continueBtn.textContent = 'Next Round';
      }
    }
    
    DOMUtils.showModal('resultModal');
  }
  
  continueAfterResult() {
    DOMUtils.hideModal('resultModal');
    
    // Check if game should restart
    if (this.playerHealth <= 0 || this.botHealth <= 0) {
      this.resetGameState();
    }
    
    // Start next round
    this.currentRound++;
    this.roundInProgress = false;
    this.startNewRound();
  }
  
  handleAchievementUnlocked(achievement) {
    Logger.log('Achievement unlocked', achievement);
    
    // Update score
    this.gameStats.updateScore(achievement.points, 'achievement bonus');
    
    // Play achievement sound
    this.soundManager.play('achievement');
    
    // Update UI
    this.updateUI();
  }
  
  updateChamberDisplay(firedChamber = null, wasLive = false) {
    const chambers = document.querySelectorAll('.chamber');
    
    chambers.forEach((chamber, index) => {
      chamber.classList.remove('live', 'fired', 'highlighted');
      
      if (firedChamber !== null && index === firedChamber) {
        if (wasLive) {
          chamber.classList.add('live');
        } else {
          chamber.classList.add('fired');
        }
      }
    });
  }
  
  setActionButtonsEnabled(enabled) {
    const fireAtSelfBtn = document.getElementById('fireAtSelf');
    const fireAtBotBtn = document.getElementById('fireAtBot');
    
    if (fireAtSelfBtn) fireAtSelfBtn.disabled = !enabled;
    if (fireAtBotBtn) fireAtBotBtn.disabled = !enabled;
  }
  
  updateRoundStatus(status) {
    DOMUtils.updateElement('roundStatus', status);
  }
  
  updateUI() {
    const stats = this.gameStats.getStats();
    
    // Update HUD
    DOMUtils.updateElement('playerScore', stats.score.toString());
    DOMUtils.updateElement('playerStreak', stats.currentStreak.toString());
    DOMUtils.updateElement('currentRound', this.currentRound.toString());
    
    // Update leaderboard page if visible
    if (this.currentPage === 'leaderboardPage') {
      this.updateLeaderboard();
    }
  }
  
  updateLeaderboard() {
    const stats = this.gameStats.getStats();
    
    // Update personal stats
    DOMUtils.updateElement('personalScore', stats.score.toString());
    DOMUtils.updateElement('personalStreak', stats.bestStreak.toString());
    DOMUtils.updateElement('personalGames', stats.totalRounds.toString());
    DOMUtils.updateElement('personalWinRate', `${stats.winRate}%`);
    
    // Update achievement gallery
    this.updateAchievementGallery();
  }
  
  updateAchievementGallery() {
    const gallery = document.getElementById('achievementGallery');
    if (!gallery) return;
    
    const stats = this.gameStats.getStats();
    const achievements = GAME_CONFIG.achievements;
    
    gallery.innerHTML = achievements.map(achievement => {
      const unlocked = stats.achievements.includes(achievement.id);
      
      return `
        <div class="achievement-card ${unlocked ? 'unlocked' : ''}">
          <div class="text-4xl mb-3">${achievement.icon}</div>
          <h3 class="font-semibold text-white mb-1">${achievement.name}</h3>
          <p class="text-sm text-light-400 mb-2">${achievement.description}</p>
          <div class="text-xs font-mono ${unlocked ? 'text-green-400' : 'text-light-600'}">
            ${unlocked ? 'UNLOCKED' : `${achievement.points} points`}
          </div>
        </div>
      `;
    }).join('');
  }
  
  toggleSound() {
    const enabled = this.soundManager.toggle();
    const button = document.getElementById('toggleSound');
    
    if (button) {
      const icon = enabled ? 
        `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.536 8.464a5 5 0 010 7.072M18.364 5.636a9 9 0 010 12.728M9 9l1.414 1.414L12 9l-1.414-1.414L9 9z"/>` :
        `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" clip-rule="evenodd"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2"/>`;
      
      button.innerHTML = `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">${icon}</svg>`;
    }
  }
  
  showPage(pageId) {
    this.currentPage = pageId;
    DOMUtils.showPage(pageId);
    
    // Update page-specific content
    if (pageId === 'leaderboardPage') {
      this.updateLeaderboard();
    }
  }
  
  exitGame() {
    // Cleanup 3D engine
    if (this.revolverRenderer) {
      this.revolverRenderer.dispose();
      this.revolverRenderer = null;
    }
    
    if (this.particleManager) {
      this.particleManager.dispose();
      this.particleManager = null;
    }
    
    // Reset state
    this.setState(GAME_STATES.WALLET_CONNECTED);
    this.roundInProgress = false;
    
    // Return to home
    this.showPage('homePage');
  }
  
  setState(newState) {
    const oldState = this.currentState;
    this.currentState = newState;
    
    Logger.log(`State: ${oldState} → ${newState}`);
  }
  
  showErrorMessage(message) {
    // Create temporary error display
    const errorEl = document.createElement('div');
    errorEl.className = 'fixed top-20 right-6 bg-red-600 text-white px-4 py-2 rounded-lg shadow-lg z-50';
    errorEl.textContent = message;
    
    document.body.appendChild(errorEl);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
      if (errorEl.parentNode) {
        errorEl.parentNode.removeChild(errorEl);
      }
    }, 5000);
  }
  
  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  // Debug methods
  getDebugInfo() {
    return {
      state: this.currentState,
      page: this.currentPage,
      roundInProgress: this.roundInProgress,
      currentRound: this.currentRound,
      playerHealth: this.playerHealth,
      botHealth: this.botHealth,
      walletConnected: this.walletManager.connected,
      stats: this.gameStats.getStats(),
      performance: window.gameLogs?.slice(-10) || []
    };
  }
}

// Initialize application when DOM is ready
let app;

document.addEventListener('DOMContentLoaded', () => {
  Logger.log('DOM loaded, initializing DApp');
  
  try {
    app = new RussianRouletteDApp();
    
    // Expose to window for debugging
    window.app = app;
    
  } catch (error) {
    Logger.error('Failed to initialize DApp', error);
    DOMUtils.hideLoading();
  }
});

// Handle page visibility changes
document.addEventListener('visibilitychange', () => {
  if (app) {
    if (document.hidden) {
      // Pause intensive operations when page is hidden
      Logger.log('Page hidden, pausing operations');
    } else {
      // Resume when page is visible
      Logger.log('Page visible, resuming operations');
      app.updateNetworkStatus();
    }
  }
});

// Handle page unload
window.addEventListener('beforeunload', () => {
  if (app && app.revolverRenderer) {
    app.revolverRenderer.dispose();
  }
  
  Logger.log('DApp shutting down');
});

// Global error handler
window.addEventListener('error', (event) => {
  Logger.error('Global error caught', {
    message: event.message,
    filename: event.filename,
    line: event.lineno,
    column: event.colno,
    error: event.error
  });
});

// Unhandled promise rejection handler
window.addEventListener('unhandledrejection', (event) => {
  Logger.error('Unhandled promise rejection', event.reason);
  event.preventDefault(); // Prevent console spam
});

// Performance monitoring
if (typeof PerformanceObserver !== 'undefined') {
  const observer = new PerformanceObserver((list) => {
    for (const entry of list.getEntries()) {
      if (entry.duration > 16.67) { // Longer than 60fps frame
        Logger.warn(`Performance: ${entry.name} took ${entry.duration.toFixed(2)}ms`);
      }
    }
  });
  
  observer.observe({ entryTypes: ['measure', 'navigation'] });
}
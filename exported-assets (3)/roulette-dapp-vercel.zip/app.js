// Main application logic for Russian Roulette DApp

class RussianRouletteDApp {
  constructor() {
    // Initialize core systems
    this.soundManager = new SoundManager();
    this.animationManager = new AnimationManager();
    this.wallet = new MockWallet();
    this.randomGenerator = new RandomGenerator();
    this.achievementManager = new AchievementManager();
    this.gameStats = new GameStats();
    
    // Game state
    this.currentState = GAME_STATES.CONNECTING_WALLET;
    this.revolverRenderer = null;
    this.playerSprite = null;
    this.botSprite = null;
    
    // Round data
    this.currentRound = 1;
    this.liveChamber = null;
    this.playerHealth = 100;
    this.botHealth = 100;
    this.roundInProgress = false;
    
    this.init();
  }

  async init() {
    console.log('Initializing Russian Roulette DApp...');
    
    // Setup event listeners
    this.setupEventListeners();
    
    // Setup achievement callbacks
    this.achievementManager.onAchievementUnlocked = (achievement) => {
      this.gameStats.updateScore(achievement.points, 'achievement bonus');
      this.soundManager.play('achievement');
      this.updateHUD();
    };
    
    // Initialize UI
    this.updateHUD();
    
    console.log('DApp initialized successfully');
  }

  setupEventListeners() {
    // Main menu buttons
    const connectWalletBtn = document.getElementById('connectWallet');
    const startGameBtn = document.getElementById('startGame');
    const exitGameBtn = document.getElementById('exitGame');
    
    // Action buttons
    const fireAtSelfBtn = document.getElementById('fireAtSelf');
    const fireAtBotBtn = document.getElementById('fireAtBot');
    
    // Modal buttons
    const continueBtn = document.getElementById('continueButton');
    
    if (connectWalletBtn) {
      connectWalletBtn.addEventListener('click', () => this.connectWallet());
    }
    
    if (startGameBtn) {
      startGameBtn.addEventListener('click', () => this.startGame());
    }
    
    if (exitGameBtn) {
      exitGameBtn.addEventListener('click', () => this.exitGame());
    }
    
    if (fireAtSelfBtn) {
      fireAtSelfBtn.addEventListener('click', () => this.playerAction(PLAYER_ACTIONS.FIRE_AT_SELF));
    }
    
    if (fireAtBotBtn) {
      fireAtBotBtn.addEventListener('click', () => this.playerAction(PLAYER_ACTIONS.FIRE_AT_BOT));
    }
    
    if (continueBtn) {
      continueBtn.addEventListener('click', () => this.continueAfterResult());
    }
  }

  async connectWallet() {
    this.setState(GAME_STATES.CONNECTING_WALLET);
    DOMUtils.showLoading('Connecting to Filecoin Network...');
    
    try {
      const walletInfo = await this.wallet.connect();
      
      // Update UI
      const walletStatus = document.getElementById('walletStatus');
      const startGameBtn = document.getElementById('startGame');
      const connectWalletBtn = document.getElementById('connectWallet');
      
      if (walletStatus) {
        walletStatus.innerHTML = `
          <div style="color: var(--game-success); font-size: var(--font-size-sm);">
            ✅ Connected to ${walletInfo.network}
          </div>
          <div style="color: var(--color-text-secondary); font-size: var(--font-size-xs); margin-top: 4px;">
            ${walletInfo.address.substring(0, 6)}...${walletInfo.address.substring(38)}
          </div>
        `;
      }
      
      if (startGameBtn) {
        startGameBtn.disabled = false;
      }
      
      if (connectWalletBtn) {
        connectWalletBtn.textContent = 'Wallet Connected';
        connectWalletBtn.disabled = true;
      }
      
      this.soundManager.play('victory');
      
    } catch (error) {
      console.error('Failed to connect wallet:', error);
      
      const walletStatus = document.getElementById('walletStatus');
      if (walletStatus) {
        walletStatus.innerHTML = `
          <div style="color: var(--game-danger); font-size: var(--font-size-sm);">
            ❌ Connection failed. Please try again.
          </div>
        `;
      }
    } finally {
      DOMUtils.hideLoading();
    }
  }

  async startGame() {
    if (!this.wallet.isConnected()) {
      alert('Please connect your wallet first!');
      return;
    }
    
    this.setState(GAME_STATES.INITIALIZING);
    DOMUtils.showLoading('Initializing game...');
    
    try {
      // Switch to game screen
      DOMUtils.showScreen('gameScreen');
      
      // Initialize 3D renderer
      await this.init3DRenderer();
      
      // Initialize character sprites
      this.playerSprite = new CharacterSprite('playerSprite');
      this.botSprite = new CharacterSprite('botSprite');
      
      // Reset game state
      this.resetGame();
      
      // Start first round
      await this.startNewRound();
      
    } catch (error) {
      console.error('Failed to start game:', error);
    } finally {
      DOMUtils.hideLoading();
    }
  }

  async init3DRenderer() {
    if (this.revolverRenderer) {
      this.revolverRenderer.dispose();
    }
    
    this.revolverRenderer = new RevolverRenderer('revolverContainer');
    
    // Wait a bit for renderer to initialize
    await new Promise(resolve => setTimeout(resolve, 500));
  }

  resetGame() {
    this.currentRound = 1;
    this.playerHealth = 100;
    this.botHealth = 100;
    this.roundInProgress = false;
    
    if (this.playerSprite) {
      this.playerSprite.updateHealth(100);
      this.playerSprite.setActive(false);
    }
    
    if (this.botSprite) {
      this.botSprite.updateHealth(100);
      this.botSprite.setActive(false);
    }
    
    this.updateHUD();
  }

  async startNewRound() {
    this.setState(GAME_STATES.INITIALIZING);
    DOMUtils.updateElement('roundStatus', `Round ${this.currentRound} - Preparing...`);
    
    // Generate random chamber position using blockchain simulation
    DOMUtils.showLoading('Generating random chamber...');
    this.liveChamber = await this.randomGenerator.generateSecureRandom(0, 5);
    DOMUtils.hideLoading();
    
    // Reset revolver visuals
    if (this.revolverRenderer) {
      this.revolverRenderer.resetChambers();
    }
    
    // Update chamber indicators in UI
    this.updateChamberDisplay();
    
    this.setState(GAME_STATES.WAITING_FOR_CHOICE);
    DOMUtils.updateElement('roundStatus', 'Choose Your Action');
    
    // Enable action buttons
    this.setActionButtonsEnabled(true);
    
    console.log(`Round ${this.currentRound} started. Live chamber: ${this.liveChamber}`);
  }

  updateChamberDisplay() {
    const chambers = document.querySelectorAll('.chamber');
    chambers.forEach((chamber, index) => {
      chamber.classList.remove('live', 'fired');
      // Don't reveal which chamber is live until after firing
    });
  }

  async playerAction(action) {
    if (this.roundInProgress || this.currentState !== GAME_STATES.WAITING_FOR_CHOICE) {
      return;
    }
    
    this.roundInProgress = true;
    this.setActionButtonsEnabled(false);
    
    // Determine target
    const target = action === PLAYER_ACTIONS.FIRE_AT_SELF ? 'player' : 'bot';
    const isPlayer = target === 'player';
    
    DOMUtils.updateElement('roundStatus', `Spinning revolver...`);
    this.setState(GAME_STATES.SPINNING_REVOLVER);
    
    // Play spin animation and sound
    this.soundManager.play('spin');
    if (this.revolverRenderer) {
      await this.revolverRenderer.spinRevolver(2000);
    }
    
    // Firing phase
    this.setState(GAME_STATES.FIRING);
    DOMUtils.updateElement('roundStatus', `Firing at ${isPlayer ? 'yourself' : 'bot'}...`);
    
    // Set active sprite
    if (isPlayer && this.playerSprite) {
      this.playerSprite.setActive(true);
    } else if (!isPlayer && this.botSprite) {
      this.botSprite.setActive(true);
    }
    
    // Generate current chamber (where bullet would be)
    const currentChamber = this.randomGenerator.quickRandom(0, 5);
    const hitLiveBullet = currentChamber === this.liveChamber;
    
    // Play firing animation
    if (this.revolverRenderer) {
      this.revolverRenderer.highlightChamber(currentChamber);
      await this.revolverRenderer.fireBullet(currentChamber);
    }
    
    this.soundManager.play('gunshot');
    
    // Character firing animation
    if (isPlayer && this.playerSprite) {
      await this.playerSprite.playAnimation('firing', 500);
    }
    
    // Determine result
    const survived = !hitLiveBullet;
    const killedTarget = hitLiveBullet && !isPlayer;
    
    // Update chamber display
    const chambers = document.querySelectorAll('.chamber');
    if (chambers[currentChamber]) {
      if (hitLiveBullet) {
        chambers[currentChamber].classList.add('live');
      } else {
        chambers[currentChamber].classList.add('fired');
      }
    }
    
    // Process result
    await this.processRoundResult(action, survived, killedTarget, isPlayer);
  }

  async processRoundResult(action, survived, killedTarget, wasPlayerAction) {
    this.setState(GAME_STATES.SHOWING_RESULT);
    
    let resultTitle, resultMessage, resultIcon;
    let playerDied = false;
    let botDied = false;
    
    if (survived) {
      if (killedTarget) {
        // Player shot bot and killed it
        resultTitle = 'Direct Hit!';
        resultMessage = 'You eliminated the bot!';
        resultIcon = '🎯';
        botDied = true;
        this.botHealth = 0;
        this.soundManager.play('victory');
        
        if (this.botSprite) {
          this.botSprite.updateHealth(0);
          await this.botSprite.playAnimation('death', 1000);
        }
      } else {
        // Blank chamber
        resultTitle = 'Lucky Shot!';
        resultMessage = wasPlayerAction ? 'You survived the blank!' : 'The bot survived!';
        resultIcon = '😅';
        this.soundManager.play('victory');
      }
    } else {
      // Live bullet hit
      if (wasPlayerAction) {
        // Player shot themselves and died
        resultTitle = 'Game Over';
        resultMessage = 'You hit the live bullet!';
        resultIcon = '💀';
        playerDied = true;
        this.playerHealth = 0;
        this.soundManager.play('death');
        
        if (this.playerSprite) {
          this.playerSprite.updateHealth(0);
          await this.playerSprite.playAnimation('death', 1000);
        }
      } else {
        // This shouldn't happen in current game logic, but handle it
        resultTitle = 'Critical Hit!';
        resultMessage = 'The bot was eliminated!';
        resultIcon = '🎯';
        botDied = true;
        this.botHealth = 0;
      }
    }
    
    // Update statistics
    this.gameStats.recordAction(action, !playerDied, botDied);
    
    // Check for achievements
    this.achievementManager.checkAchievements(this.gameStats.getStats());
    
    // Show result modal
    this.showResultModal(resultTitle, resultMessage, resultIcon, playerDied, botDied);
    
    // Clear active states
    if (this.playerSprite) this.playerSprite.setActive(false);
    if (this.botSprite) this.botSprite.setActive(false);
    
    this.setState(GAME_STATES.UPDATING_SCORE);
    this.updateHUD();
  }

  showResultModal(title, message, icon, playerDied, botDied) {
    // Update modal content
    DOMUtils.updateElement('resultIcon', icon);
    DOMUtils.updateElement('resultTitle', title);
    DOMUtils.updateElement('resultMessage', message);
    
    // Show score change
    const scoreChangeElement = document.getElementById('scoreChange');
    const stats = this.gameStats.getStats();
    
    if (scoreChangeElement) {
      const lastScore = stats.score; // Current score after update
      let change = 0;
      
      if (playerDied) {
        change = GAME_CONFIG.scoring.death_penalty;
        scoreChangeElement.textContent = `${change} points`;
        scoreChangeElement.className = 'score-change negative';
      } else {
        // Could be streak bonus or just survival
        scoreChangeElement.textContent = `Score: ${stats.score}`;
        scoreChangeElement.className = 'score-change';
      }
    }
    
    // Update continue button text based on outcome
    const continueBtn = document.getElementById('continueButton');
    if (continueBtn) {
      if (playerDied || botDied) {
        continueBtn.textContent = 'New Game';
      } else {
        continueBtn.textContent = 'Next Round';
      }
    }
    
    DOMUtils.showModal('resultModal');
  }

  continueAfterResult() {
    DOMUtils.hideModal('resultModal');
    
    // Check if game should continue or restart
    if (this.playerHealth <= 0 || this.botHealth <= 0) {
      // Game over, start new game
      this.resetGame();
    }
    
    // Next round
    this.currentRound++;
    this.roundInProgress = false;
    this.startNewRound();
  }

  exitGame() {
    // Cleanup 3D renderer
    if (this.revolverRenderer) {
      this.revolverRenderer.dispose();
      this.revolverRenderer = null;
    }
    
    // Return to main menu
    DOMUtils.showScreen('mainMenu');
    
    // Reset game state
    this.resetGame();
    this.setState(GAME_STATES.CONNECTING_WALLET);
  }

  setActionButtonsEnabled(enabled) {
    const fireAtSelfBtn = document.getElementById('fireAtSelf');
    const fireAtBotBtn = document.getElementById('fireAtBot');
    
    if (fireAtSelfBtn) fireAtSelfBtn.disabled = !enabled;
    if (fireAtBotBtn) fireAtBotBtn.disabled = !enabled;
  }

  updateHUD() {
    const stats = this.gameStats.getStats();
    
    DOMUtils.updateElement('playerScore', stats.score.toString());
    DOMUtils.updateElement('playerStreak', stats.currentStreak.toString());
    DOMUtils.updateElement('currentRound', this.currentRound.toString());
  }

  setState(newState) {
    this.currentState = newState;
    console.log(`Game state changed to: ${newState}`);
  }
}

// Bot AI (simple implementation)
class BotAI {
  constructor() {
    this.lastAction = null;
    this.aggression = 0.5; // 0 = always shoots self, 1 = always shoots player
  }

  makeDecision(gameState) {
    // Simple AI: 50% chance to shoot self, 50% to shoot player
    // In a real implementation, this could be more sophisticated
    const random = Math.random();
    
    if (random < 0.5) {
      this.lastAction = PLAYER_ACTIONS.FIRE_AT_SELF;
    } else {
      this.lastAction = PLAYER_ACTIONS.FIRE_AT_BOT;
    }
    
    return this.lastAction;
  }

  adjustAggression(survived, killedOpponent) {
    if (survived && killedOpponent) {
      this.aggression += 0.1; // Become more aggressive after success
    } else if (!survived) {
      this.aggression -= 0.1; // Become more cautious after death
    }
    
    this.aggression = Math.max(0, Math.min(1, this.aggression));
  }
}

// Initialize the application when DOM is loaded
let app;

document.addEventListener('DOMContentLoaded', () => {
  console.log('DOM loaded, initializing Russian Roulette DApp...');
  app = new RussianRouletteDApp();
});

// Handle page unload
window.addEventListener('beforeunload', () => {
  if (app && app.revolverRenderer) {
    app.revolverRenderer.dispose();
  }
});

// Export for debugging
if (typeof window !== 'undefined') {
  window.RussianRouletteDApp = RussianRouletteDApp;
  window.BotAI = BotAI;
}
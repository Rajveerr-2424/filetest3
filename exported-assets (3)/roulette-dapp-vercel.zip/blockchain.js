// Russian Roulette DApp - Blockchain Integration
// Filecoin testnet integration with wallet management and smart contract simulation

// Filecoin Network Configuration
const FILECOIN_CONFIG = {
  chainId: 314159,
  chainIdHex: '0x4cb2f',
  networkName: 'Filecoin Calibration',
  currency: 'tFIL',
  decimals: 18,
  rpcUrl: 'https://api.calibration.node.glif.io/rpc/v1',
  explorerUrl: 'https://calibration.filscan.io',
  blockTime: 30000, // 30 seconds
  gasLimit: 1000000,
  gasPrice: '1000000000' // 1 nanoFIL
};

// Mock Contract Configuration (placeholder for real deployment)
const CONTRACT_CONFIG = {
  address: '0x0000000000000000000000000000000000000000', // Update after deployment
  abi: [
    // Game functions
    {
      "name": "playRound",
      "type": "function",
      "inputs": [{"name": "target", "type": "uint8"}],
      "outputs": [{"name": "requestId", "type": "bytes32"}]
    },
    {
      "name": "getPlayerStats",
      "type": "function",
      "inputs": [{"name": "player", "type": "address"}],
      "outputs": [
        {"name": "score", "type": "uint256"},
        {"name": "streak", "type": "uint256"},
        {"name": "totalRounds", "type": "uint256"}
      ]
    },
    // Events
    {
      "name": "RoundRequested",
      "type": "event",
      "inputs": [
        {"name": "player", "type": "address", "indexed": true},
        {"name": "requestId", "type": "bytes32", "indexed": true},
        {"name": "target", "type": "uint8"}
      ]
    },
    {
      "name": "RoundSettled",
      "type": "event",
      "inputs": [
        {"name": "player", "type": "address", "indexed": true},
        {"name": "requestId", "type": "bytes32", "indexed": true},
        {"name": "randomValue", "type": "uint256"},
        {"name": "survived", "type": "bool"},
        {"name": "scoreChange", "type": "int256"}
      ]
    }
  ]
};

// Wallet Management Class
class WalletManager {
  constructor() {
    this.provider = null;
    this.signer = null;
    this.address = null;
    this.connected = false;
    this.networkCorrect = false;
    this.balance = '0';
    
    this.eventListeners = new Map();
    
    // Check for existing connection
    this.checkConnection();
  }
  
  async checkConnection() {
    if (typeof window.ethereum !== 'undefined') {
      try {
        const accounts = await window.ethereum.request({ method: 'eth_accounts' });
        if (accounts.length > 0) {
          this.address = accounts[0];
          this.connected = true;
          await this.checkNetwork();
          await this.updateBalance();
          this.emit('connected', { address: this.address });
        }
      } catch (error) {
        Logger.error('Error checking existing connection', error);
      }
    }
  }
  
  async connect() {
    DOMUtils.showLoading('Connecting to MetaMask...');
    
    try {
      if (typeof window.ethereum === 'undefined') {
        throw new Error('MetaMask not installed. Please install MetaMask to continue.');
      }
      
      // Request account access
      const accounts = await window.ethereum.request({
        method: 'eth_requestAccounts'
      });
      
      if (accounts.length === 0) {
        throw new Error('No accounts found. Please unlock MetaMask.');
      }
      
      this.address = accounts[0];
      this.connected = true;
      
      Logger.log('Wallet connected', this.address);
      
      // Check and switch network if needed
      await this.ensureCorrectNetwork();
      
      // Update balance
      await this.updateBalance();
      
      // Setup event listeners
      this.setupEventListeners();
      
      this.emit('connected', { 
        address: this.address,
        network: FILECOIN_CONFIG.networkName 
      });
      
      return {
        address: this.address,
        network: FILECOIN_CONFIG.networkName,
        balance: this.balance
      };
      
    } catch (error) {
      Logger.error('Failed to connect wallet', error);
      this.emit('error', error);
      throw error;
    } finally {
      DOMUtils.hideLoading();
    }
  }
  
  async ensureCorrectNetwork() {
    try {
      const chainId = await window.ethereum.request({ method: 'eth_chainId' });
      
      if (chainId !== FILECOIN_CONFIG.chainIdHex) {
        Logger.log('Wrong network detected, switching to Filecoin Calibration');
        
        try {
          // Try to switch to Filecoin network
          await window.ethereum.request({
            method: 'wallet_switchEthereumChain',
            params: [{ chainId: FILECOIN_CONFIG.chainIdHex }]
          });
        } catch (switchError) {
          // Network might not be added to MetaMask yet
          if (switchError.code === 4902) {
            await this.addFilecoinNetwork();
          } else {
            throw switchError;
          }
        }
      }
      
      this.networkCorrect = true;
      Logger.log('Connected to Filecoin Calibration network');
      
    } catch (error) {
      Logger.error('Failed to ensure correct network', error);
      this.networkCorrect = false;
      throw new Error('Please switch to Filecoin Calibration testnet in MetaMask');
    }
  }
  
  async addFilecoinNetwork() {
    try {
      await window.ethereum.request({
        method: 'wallet_addEthereumChain',
        params: [{
          chainId: FILECOIN_CONFIG.chainIdHex,
          chainName: FILECOIN_CONFIG.networkName,
          nativeCurrency: {
            name: 'Filecoin',
            symbol: FILECOIN_CONFIG.currency,
            decimals: FILECOIN_CONFIG.decimals
          },
          rpcUrls: [FILECOIN_CONFIG.rpcUrl],
          blockExplorerUrls: [FILECOIN_CONFIG.explorerUrl]
        }]
      });
      
      Logger.log('Filecoin network added to MetaMask');
    } catch (error) {
      Logger.error('Failed to add Filecoin network', error);
      throw new Error('Failed to add Filecoin network to MetaMask');
    }
  }
  
  async updateBalance() {
    if (!this.connected || !this.address) return;
    
    try {
      const balance = await window.ethereum.request({
        method: 'eth_getBalance',
        params: [this.address, 'latest']
      });
      
      // Convert from wei to tFIL
      const balanceInFIL = parseInt(balance, 16) / Math.pow(10, FILECOIN_CONFIG.decimals);
      this.balance = balanceInFIL.toFixed(4);
      
      this.emit('balanceUpdated', { balance: this.balance });
      
    } catch (error) {
      Logger.warn('Failed to update balance', error);
    }
  }
  
  setupEventListeners() {
    if (window.ethereum) {
      // Account changes
      window.ethereum.on('accountsChanged', (accounts) => {
        if (accounts.length === 0) {
          this.disconnect();
        } else {
          this.address = accounts[0];
          this.updateBalance();
          this.emit('accountChanged', { address: this.address });
        }
      });
      
      // Network changes
      window.ethereum.on('chainChanged', (chainId) => {
        this.networkCorrect = chainId === FILECOIN_CONFIG.chainIdHex;
        this.emit('networkChanged', { 
          chainId, 
          correct: this.networkCorrect 
        });
        
        if (this.networkCorrect) {
          this.updateBalance();
        }
      });
    }
  }
  
  disconnect() {
    this.address = null;
    this.connected = false;
    this.networkCorrect = false;
    this.balance = '0';
    
    this.emit('disconnected');
    Logger.log('Wallet disconnected');
  }
  
  // Event emitter methods
  on(event, callback) {
    if (!this.eventListeners.has(event)) {
      this.eventListeners.set(event, []);
    }
    this.eventListeners.get(event).push(callback);
  }
  
  emit(event, data) {
    if (this.eventListeners.has(event)) {
      this.eventListeners.get(event).forEach(callback => {
        try {
          callback(data);
        } catch (error) {
          Logger.error(`Error in event listener for ${event}`, error);
        }
      });
    }
  }
  
  getConnectionInfo() {
    return {
      connected: this.connected,
      address: this.address,
      networkCorrect: this.networkCorrect,
      balance: this.balance,
      network: FILECOIN_CONFIG.networkName
    };
  }
}

// Smart Contract Interface (Mock Implementation)
class GameContract {
  constructor(walletManager) {
    this.walletManager = walletManager;
    this.address = CONTRACT_CONFIG.address;
    this.abi = CONTRACT_CONFIG.abi;
    
    // Mock blockchain state
    this.playerStats = new Map();
    this.pendingRequests = new Map();
    this.gameHistory = [];
    
    this.eventListeners = new Map();
    
    Logger.log('GameContract initialized', this.address);
  }
  
  // Simulate playing a round on the blockchain
  async playRound(target) {
    if (!this.walletManager.connected) {
      throw new Error('Wallet not connected');
    }
    
    if (!this.walletManager.networkCorrect) {
      throw new Error('Please switch to Filecoin Calibration network');
    }
    
    const player = this.walletManager.address;
    const requestId = this.generateRequestId();
    
    Logger.log('Initiating round on blockchain', { player, target, requestId });
    
    DOMUtils.showTransactionStatus('Submitting transaction to blockchain...');
    
    try {
      // Simulate transaction submission delay
      await this.delay(1500);
      
      // Emit RoundRequested event
      this.emit('RoundRequested', {
        player,
        requestId,
        target,
        blockNumber: await this.getCurrentBlockNumber(),
        transactionHash: this.generateTxHash()
      });
      
      DOMUtils.showTransactionStatus('Waiting for VRF randomness...');
      
      // Store pending request
      this.pendingRequests.set(requestId, {
        player,
        target,
        timestamp: Date.now()
      });
      
      // Simulate VRF callback delay (blockchain randomness)
      setTimeout(() => {
        this.fulfillRandomness(requestId);
      }, 2000 + Math.random() * 2000);
      
      return { requestId, transactionHash: this.generateTxHash() };
      
    } catch (error) {
      DOMUtils.hideTransactionStatus();
      Logger.error('Failed to play round', error);
      throw error;
    }
  }
  
  async fulfillRandomness(requestId) {
    const request = this.pendingRequests.get(requestId);
    if (!request) {
      Logger.error('Request not found', requestId);
      return;
    }
    
    const { player, target } = request;
    
    // Generate cryptographically simulated random value
    const randomValue = await this.generateSecureRandom();
    const chamberPosition = randomValue % 6;
    const liveBullet = 0; // Fixed position for simplicity
    
    // Determine outcome
    const hitLiveBullet = chamberPosition === liveBullet;
    const survived = target === 0 ? !hitLiveBullet : hitLiveBullet; // 0 = self, 1 = bot
    const killedBot = target === 1 && hitLiveBullet;
    
    // Calculate score change
    let scoreChange = 0;
    if (survived) {
      scoreChange += GAME_CONFIG.scoring.survivalBonus;
      if (killedBot) {
        scoreChange += GAME_CONFIG.scoring.killBonus;
      }
    } else {
      scoreChange = GAME_CONFIG.scoring.deathPenalty;
    }
    
    // Update player stats
    this.updatePlayerStats(player, survived, scoreChange);
    
    // Store in history
    this.gameHistory.push({
      requestId,
      player,
      target,
      randomValue,
      chamberPosition,
      survived,
      killedBot,
      scoreChange,
      timestamp: Date.now(),
      blockNumber: await this.getCurrentBlockNumber()
    });
    
    // Remove from pending
    this.pendingRequests.delete(requestId);
    
    Logger.log('Round settled', {
      requestId,
      randomValue,
      chamberPosition,
      survived,
      scoreChange
    });
    
    // Emit RoundSettled event
    this.emit('RoundSettled', {
      player,
      requestId,
      randomValue,
      chamberPosition,
      survived,
      killedBot,
      scoreChange,
      transactionHash: this.generateTxHash()
    });
    
    DOMUtils.hideTransactionStatus();
  }
  
  updatePlayerStats(player, survived, scoreChange) {
    if (!this.playerStats.has(player)) {
      this.playerStats.set(player, {
        score: 0,
        streak: 0,
        totalRounds: 0,
        wins: 0,
        losses: 0
      });
    }
    
    const stats = this.playerStats.get(player);
    stats.totalRounds++;
    stats.score = Math.max(0, stats.score + scoreChange);
    
    if (survived) {
      stats.wins++;
      stats.streak++;
    } else {
      stats.losses++;
      stats.streak = 0;
    }
    
    this.playerStats.set(player, stats);
  }
  
  async getPlayerStats(player = null) {
    const address = player || this.walletManager.address;
    if (!address) {
      throw new Error('No player address provided');
    }
    
    // Simulate blockchain call delay
    await this.delay(500);
    
    const stats = this.playerStats.get(address) || {
      score: 0,
      streak: 0,
      totalRounds: 0,
      wins: 0,
      losses: 0
    };
    
    return stats;
  }
  
  async getGameHistory(player = null, limit = 10) {
    const address = player || this.walletManager.address;
    
    return this.gameHistory
      .filter(entry => !address || entry.player === address)
      .slice(-limit)
      .reverse();
  }
  
  async generateSecureRandom() {
    // Simulate VRF (Verifiable Random Function) from blockchain
    const entropy = [
      Date.now(),
      Math.random(),
      this.walletManager.address,
      performance.now()
    ].join('');
    
    // Simple hash function
    let hash = 0;
    for (let i = 0; i < entropy.length; i++) {
      hash = ((hash << 5) - hash + entropy.charCodeAt(i)) & 0xffffffff;
    }
    
    return Math.abs(hash);
  }
  
  generateRequestId() {
    return '0x' + Array.from({length: 64}, () => 
      Math.floor(Math.random() * 16).toString(16)
    ).join('');
  }
  
  generateTxHash() {
    return '0x' + Array.from({length: 64}, () => 
      Math.floor(Math.random() * 16).toString(16)
    ).join('');
  }
  
  async getCurrentBlockNumber() {
    // Simulate current block number
    return Math.floor(Date.now() / FILECOIN_CONFIG.blockTime) + 1000000;
  }
  
  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  // Event emitter methods
  on(event, callback) {
    if (!this.eventListeners.has(event)) {
      this.eventListeners.set(event, []);
    }
    this.eventListeners.get(event).push(callback);
  }
  
  emit(event, data) {
    if (this.eventListeners.has(event)) {
      this.eventListeners.get(event).forEach(callback => {
        try {
          callback(data);
        } catch (error) {
          Logger.error(`Error in contract event listener for ${event}`, error);
        }
      });
    }
  }
  
  // Get contract info
  getContractInfo() {
    return {
      address: this.address,
      network: FILECOIN_CONFIG.networkName,
      chainId: FILECOIN_CONFIG.chainId,
      pendingRequests: this.pendingRequests.size,
      totalGames: this.gameHistory.length
    };
  }
}

// Transaction Monitor
class TransactionMonitor {
  constructor(walletManager, contract) {
    this.walletManager = walletManager;
    this.contract = contract;
    this.pendingTransactions = new Map();
  }
  
  async waitForTransaction(txHash, description = 'Transaction') {
    Logger.log('Monitoring transaction', txHash);
    
    DOMUtils.showTransactionStatus(`${description} pending...`);
    
    // Simulate transaction confirmation delay
    const confirmationTime = 5000 + Math.random() * 10000; // 5-15 seconds
    
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        DOMUtils.hideTransactionStatus();
        reject(new Error('Transaction timeout'));
      }, 30000); // 30 second timeout
      
      setTimeout(() => {
        clearTimeout(timeout);
        DOMUtils.hideTransactionStatus();
        Logger.log('Transaction confirmed', txHash);
        resolve({ transactionHash: txHash, status: 'confirmed' });
      }, confirmationTime);
    });
  }
  
  addPendingTransaction(txHash, type, data = {}) {
    this.pendingTransactions.set(txHash, {
      type,
      data,
      timestamp: Date.now(),
      status: 'pending'
    });
  }
  
  getPendingTransactions() {
    return Array.from(this.pendingTransactions.entries());
  }
}

// Blockchain Utils
class BlockchainUtils {
  static formatAddress(address) {
    if (!address) return '';
    return `${address.substring(0, 6)}...${address.substring(38)}`;
  }
  
  static formatBalance(balance, decimals = 4) {
    const num = parseFloat(balance);
    return num.toFixed(decimals);
  }
  
  static getExplorerUrl(txHash) {
    return `${FILECOIN_CONFIG.explorerUrl}/tx/${txHash}`;
  }
  
  static getAddressUrl(address) {
    return `${FILECOIN_CONFIG.explorerUrl}/address/${address}`;
  }
  
  static async estimateGas(transaction) {
    // Mock gas estimation
    return {
      gasLimit: FILECOIN_CONFIG.gasLimit,
      gasPrice: FILECOIN_CONFIG.gasPrice,
      estimatedCost: '0.001' // tFIL
    };
  }
}

// Error Handler for blockchain operations
class BlockchainErrorHandler {
  static handle(error) {
    Logger.error('Blockchain error', error);
    
    if (error.code === 4001) {
      // User rejected
      return 'Transaction was cancelled by user';
    } else if (error.code === 4902) {
      // Network not added
      return 'Please add Filecoin Calibration network to MetaMask';
    } else if (error.code === -32002) {
      // Request pending
      return 'A MetaMask request is already pending. Please check MetaMask.';
    } else if (error.message?.includes('insufficient funds')) {
      return 'Insufficient tFIL balance to complete transaction';
    } else if (error.message?.includes('network')) {
      return 'Network connection error. Please check your connection.';
    }
    
    return error.message || 'An unknown blockchain error occurred';
  }
}

// Export classes to window object
if (typeof window !== 'undefined') {
  window.FILECOIN_CONFIG = FILECOIN_CONFIG;
  window.CONTRACT_CONFIG = CONTRACT_CONFIG;
  window.WalletManager = WalletManager;
  window.GameContract = GameContract;
  window.TransactionMonitor = TransactionMonitor;
  window.BlockchainUtils = BlockchainUtils;
  window.BlockchainErrorHandler = BlockchainErrorHandler;
  
  Logger.log('Blockchain module loaded successfully');
}

// Initialize global instances
window.walletManager = new WalletManager();
window.gameContract = new GameContract(window.walletManager);
window.transactionMonitor = new TransactionMonitor(window.walletManager, window.gameContract);
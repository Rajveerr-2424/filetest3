// Russian Roulette DApp - Three.js 3D Engine
// Advanced 3D rendering engine for the revolver and game effects

// Check Three.js availability
if (typeof THREE === 'undefined') {
  console.error('Three.js not loaded! 3D features will be disabled.');
  window.threeJsAvailable = false;
} else {
  window.threeJsAvailable = true;
  console.log('Three.js loaded successfully, version:', THREE.REVISION);
}

// 3D Revolver Renderer Class
class RevolverRenderer {
  constructor(containerId) {
    this.containerId = containerId;
    this.container = document.getElementById(containerId);
    
    if (!this.container) {
      console.error(`Container ${containerId} not found`);
      return;
    }
    
    if (!window.threeJsAvailable) {
      this.renderFallback();
      return;
    }
    
    // Three.js objects
    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.revolverGroup = null;
    this.chambers = [];
    this.muzzleFlash = null;
    this.particles = null;
    
    // Animation state
    this.isSpinning = false;
    this.animationId = null;
    this.currentRotation = 0;
    
    // Lighting
    this.lights = {
      ambient: null,
      directional: null,
      point: null,
      spot: null
    };
    
    this.init();
  }
  
  init() {
    try {
      this.setupScene();
      this.setupCamera();
      this.setupRenderer();
      this.setupLighting();
      this.createRevolver();
      this.createMuzzleFlash();
      this.setupEventListeners();
      this.startRenderLoop();
      
      Logger.log('RevolverRenderer initialized successfully');
    } catch (error) {
      Logger.error('Failed to initialize RevolverRenderer', error);
      this.renderFallback();
    }
  }
  
  setupScene() {
    this.scene = new THREE.Scene();
    this.scene.background = null; // Transparent
    
    // Add fog for atmospheric effect
    this.scene.fog = new THREE.Fog(0x000000, 8, 15);
  }
  
  setupCamera() {
    const aspect = this.container.clientWidth / this.container.clientHeight;
    const frustumSize = 6;
    
    // Orthographic camera for 2D-in-3D style
    this.camera = new THREE.OrthographicCamera(
      frustumSize * aspect / -2,
      frustumSize * aspect / 2,
      frustumSize / 2,
      frustumSize / -2,
      0.1,
      100
    );
    
    this.camera.position.set(0, 0, 10);
    this.camera.lookAt(0, 0, 0);
  }
  
  setupRenderer() {
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance'
    });
    
    this.renderer.setSize(this.container.clientWidth, this.container.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    
    // Enable shadows
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    
    // Tone mapping
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.0;
    
    this.container.appendChild(this.renderer.domElement);
  }
  
  setupLighting() {
    // Ambient light
    this.lights.ambient = new THREE.AmbientLight(0x404040, 0.4);
    this.scene.add(this.lights.ambient);
    
    // Main directional light
    this.lights.directional = new THREE.DirectionalLight(0xffffff, 0.8);
    this.lights.directional.position.set(5, 5, 5);
    this.lights.directional.castShadow = true;
    
    // Shadow settings
    this.lights.directional.shadow.mapSize.width = 2048;
    this.lights.directional.shadow.mapSize.height = 2048;
    this.lights.directional.shadow.camera.near = 0.5;
    this.lights.directional.shadow.camera.far = 50;
    this.lights.directional.shadow.camera.left = -10;
    this.lights.directional.shadow.camera.right = 10;
    this.lights.directional.shadow.camera.top = 10;
    this.lights.directional.shadow.camera.bottom = -10;
    
    this.scene.add(this.lights.directional);
    
    // Point light for dramatic effect
    this.lights.point = new THREE.PointLight(0xff4444, 0.6, 20);
    this.lights.point.position.set(0, 0, 5);
    this.scene.add(this.lights.point);
    
    // Spot light for the revolver
    this.lights.spot = new THREE.SpotLight(0xffffff, 0.5, 30, Math.PI / 6, 0.1);
    this.lights.spot.position.set(0, 5, 5);
    this.lights.spot.target.position.set(0, 0, 0);
    this.lights.spot.castShadow = true;
    this.scene.add(this.lights.spot);
    this.scene.add(this.lights.spot.target);
  }
  
  createRevolver() {
    this.revolverGroup = new THREE.Group();
    
    // Materials
    const metalMaterial = new THREE.MeshPhongMaterial({
      color: 0x666666,
      shininess: 100,
      specular: 0x222222
    });
    
    const darkMetalMaterial = new THREE.MeshPhongMaterial({
      color: 0x333333,
      shininess: 80,
      specular: 0x111111
    });
    
    const woodMaterial = new THREE.MeshLambertMaterial({
      color: 0x8B4513
    });
    
    // Main cylinder (chamber)
    const cylinderGeometry = new THREE.CylinderGeometry(1.2, 1.2, 0.4, 32);
    const cylinder = new THREE.Mesh(cylinderGeometry, metalMaterial);
    cylinder.rotation.x = Math.PI / 2;
    cylinder.castShadow = true;
    cylinder.receiveShadow = true;
    this.revolverGroup.add(cylinder);
    
    // Barrel
    const barrelGeometry = new THREE.CylinderGeometry(0.2, 0.25, 3, 16);
    const barrel = new THREE.Mesh(barrelGeometry, darkMetalMaterial);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.z = 1.7;
    barrel.castShadow = true;
    this.revolverGroup.add(barrel);
    
    // Grip
    const gripGeometry = new THREE.BoxGeometry(0.4, 1.5, 0.3);
    const grip = new THREE.Mesh(gripGeometry, woodMaterial);
    grip.position.set(0, -1, -0.3);
    grip.castShadow = true;
    this.revolverGroup.add(grip);
    
    // Trigger guard
    const guardGeometry = new THREE.TorusGeometry(0.6, 0.05, 8, 16, Math.PI);
    const guard = new THREE.Mesh(guardGeometry, metalMaterial);
    guard.position.set(0, -0.3, -0.1);
    guard.rotation.x = Math.PI;
    this.revolverGroup.add(guard);
    
    // Trigger
    const triggerGeometry = new THREE.BoxGeometry(0.1, 0.3, 0.05);
    const trigger = new THREE.Mesh(triggerGeometry, metalMaterial);
    trigger.position.set(0, -0.4, -0.1);
    this.revolverGroup.add(trigger);
    
    // Hammer
    const hammerGeometry = new THREE.BoxGeometry(0.2, 0.3, 0.1);
    const hammer = new THREE.Mesh(hammerGeometry, darkMetalMaterial);
    hammer.position.set(0, 0.5, -0.5);
    this.revolverGroup.add(hammer);
    
    // Chamber holes
    this.chambers = [];
    const chamberMaterial = new THREE.MeshPhongMaterial({
      color: 0x444444,
      shininess: 50
    });
    
    for (let i = 0; i < 6; i++) {
      const angle = (i / 6) * Math.PI * 2;
      const chamberGeometry = new THREE.CylinderGeometry(0.15, 0.15, 0.2, 8);
      const chamber = new THREE.Mesh(chamberGeometry, chamberMaterial.clone());
      
      chamber.position.x = Math.cos(angle) * 0.7;
      chamber.position.y = Math.sin(angle) * 0.7;
      chamber.position.z = 0.1;
      chamber.rotation.x = Math.PI / 2;
      
      chamber.userData = { index: i, angle: angle };
      this.chambers.push(chamber);
      this.revolverGroup.add(chamber);
    }
    
    // Add the revolver to the scene
    this.scene.add(this.revolverGroup);
    
    // Create a platform/base
    const baseGeometry = new THREE.CylinderGeometry(2, 2, 0.1, 32);
    const baseMaterial = new THREE.MeshLambertMaterial({
      color: 0x222222,
      transparent: true,
      opacity: 0.3
    });
    const base = new THREE.Mesh(baseGeometry, baseMaterial);
    base.position.y = -2;
    base.receiveShadow = true;
    this.scene.add(base);
  }
  
  createMuzzleFlash() {
    // Muzzle flash group
    this.muzzleFlash = new THREE.Group();
    
    // Main flash cone
    const flashGeometry = new THREE.ConeGeometry(0.8, 1.5, 8);
    const flashMaterial = new THREE.MeshBasicMaterial({
      color: 0xffff00,
      transparent: true,
      opacity: 0
    });
    const flash = new THREE.Mesh(flashGeometry, flashMaterial);
    flash.rotation.x = Math.PI / 2;
    flash.position.z = 3.2;
    this.muzzleFlash.add(flash);
    
    // Secondary flash
    const flash2Geometry = new THREE.SphereGeometry(0.5, 16, 16);
    const flash2Material = new THREE.MeshBasicMaterial({
      color: 0xff6600,
      transparent: true,
      opacity: 0
    });
    const flash2 = new THREE.Mesh(flash2Geometry, flash2Material);
    flash2.position.z = 3.0;
    this.muzzleFlash.add(flash2);
    
    // Particle system
    const particleCount = 50;
    const particleGeometry = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const velocities = new Float32Array(particleCount * 3);
    
    for (let i = 0; i < particleCount * 3; i += 3) {
      positions[i] = (Math.random() - 0.5) * 2;
      positions[i + 1] = (Math.random() - 0.5) * 2;
      positions[i + 2] = 3 + Math.random() * 2;
      
      velocities[i] = (Math.random() - 0.5) * 0.1;
      velocities[i + 1] = (Math.random() - 0.5) * 0.1;
      velocities[i + 2] = Math.random() * 0.2;
    }
    
    particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particleGeometry.setAttribute('velocity', new THREE.BufferAttribute(velocities, 3));
    
    const particleMaterial = new THREE.PointsMaterial({
      color: 0xff8800,
      size: 0.1,
      transparent: true,
      opacity: 0
    });
    
    this.particles = new THREE.Points(particleGeometry, particleMaterial);
    this.muzzleFlash.add(this.particles);
    
    this.scene.add(this.muzzleFlash);
  }
  
  async spinRevolver(duration = 3000) {
    if (this.isSpinning) return Promise.resolve();
    
    this.isSpinning = true;
    const startRotation = this.revolverGroup.rotation.z;
    const totalRotation = Math.PI * 6 + (Math.random() * Math.PI * 2); // 3+ full rotations
    
    return new Promise((resolve) => {
      const startTime = Date.now();
      
      const animate = () => {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        // Easing function for realistic deceleration
        const easeOut = 1 - Math.pow(1 - progress, 4);
        
        this.revolverGroup.rotation.z = startRotation + (totalRotation * easeOut);
        this.currentRotation = this.revolverGroup.rotation.z;
        
        if (progress < 1) {
          requestAnimationFrame(animate);
        } else {
          this.isSpinning = false;
          resolve();
        }
      };
      
      animate();
    });
  }
  
  async fireBullet(chamberIndex) {
    if (!this.muzzleFlash || !this.chambers[chamberIndex]) {
      return Promise.resolve();
    }
    
    // Highlight the fired chamber
    this.highlightChamber(chamberIndex, true);
    
    // Muzzle flash animation
    const flashMesh = this.muzzleFlash.children[0];
    const flash2Mesh = this.muzzleFlash.children[1];
    const particles = this.particles;
    
    return new Promise((resolve) => {
      // Screen shake effect
      this.shakeCamera(0.1, 300);
      
      // Flash animation
      if (flashMesh && flash2Mesh && particles) {
        const startTime = Date.now();
        const duration = 800;
        
        const animate = () => {
          const elapsed = Date.now() - startTime;
          const progress = Math.min(elapsed / duration, 1);
          
          if (progress < 0.1) {
            // Quick flash
            const intensity = 1 - (progress / 0.1);
            flashMesh.material.opacity = intensity;
            flash2Mesh.material.opacity = intensity * 0.7;
            particles.material.opacity = intensity * 0.8;
            
            // Scale effect
            const scale = 1 + intensity * 2;
            flashMesh.scale.set(scale, scale, scale);
            flash2Mesh.scale.set(scale, scale, scale);
          } else {
            // Fade out
            flashMesh.material.opacity = 0;
            flash2Mesh.material.opacity = 0;
            particles.material.opacity = 0;
            flashMesh.scale.set(1, 1, 1);
            flash2Mesh.scale.set(1, 1, 1);
          }
          
          if (progress < 1) {
            requestAnimationFrame(animate);
          } else {
            resolve();
          }
        };
        
        animate();
      } else {
        resolve();
      }
    });
  }
  
  shakeCamera(intensity = 0.1, duration = 300) {
    const originalPosition = this.camera.position.clone();
    const startTime = Date.now();
    
    const shake = () => {
      const elapsed = Date.now() - startTime;
      const progress = elapsed / duration;
      
      if (progress < 1) {
        const shakeX = (Math.random() - 0.5) * intensity * (1 - progress);
        const shakeY = (Math.random() - 0.5) * intensity * (1 - progress);
        
        this.camera.position.x = originalPosition.x + shakeX;
        this.camera.position.y = originalPosition.y + shakeY;
        
        requestAnimationFrame(shake);
      } else {
        this.camera.position.copy(originalPosition);
      }
    };
    
    shake();
  }
  
  highlightChamber(index, fired = false) {
    // Reset all chambers
    this.chambers.forEach(chamber => {
      chamber.material.color.setHex(0x444444);
      chamber.material.emissive.setHex(0x000000);
    });
    
    // Highlight specified chamber
    if (this.chambers[index]) {
      if (fired) {
        this.chambers[index].material.color.setHex(0xff4444);
        this.chambers[index].material.emissive.setHex(0x442222);
      } else {
        this.chambers[index].material.color.setHex(0xffff44);
        this.chambers[index].material.emissive.setHex(0x444422);
      }
    }
  }
  
  resetChambers() {
    this.chambers.forEach(chamber => {
      chamber.material.color.setHex(0x444444);
      chamber.material.emissive.setHex(0x000000);
    });
  }
  
  startRenderLoop() {
    const render = () => {
      this.animationId = requestAnimationFrame(render);
      
      // Subtle idle rotation when not spinning
      if (!this.isSpinning && this.revolverGroup) {
        this.revolverGroup.rotation.z += 0.002;
        this.currentRotation = this.revolverGroup.rotation.z;
      }
      
      // Animate point light
      if (this.lights.point) {
        const time = Date.now() * 0.001;
        this.lights.point.intensity = 0.6 + Math.sin(time * 2) * 0.2;
      }
      
      // Render the scene
      if (this.renderer && this.scene && this.camera) {
        this.renderer.render(this.scene, this.camera);
      }
    };
    
    render();
  }
  
  setupEventListeners() {
    window.addEventListener('resize', () => this.handleResize());
  }
  
  handleResize() {
    if (!this.container || !this.camera || !this.renderer) return;
    
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    
    // Update camera
    const aspect = width / height;
    const frustumSize = 6;
    this.camera.left = frustumSize * aspect / -2;
    this.camera.right = frustumSize * aspect / 2;
    this.camera.top = frustumSize / 2;
    this.camera.bottom = frustumSize / -2;
    this.camera.updateProjectionMatrix();
    
    // Update renderer
    this.renderer.setSize(width, height);
  }
  
  renderFallback() {
    // Fallback for when Three.js is not available
    this.container.innerHTML = `
      <div style="
        width: 100%; 
        height: 100%; 
        display: flex; 
        align-items: center; 
        justify-content: center;
        background: radial-gradient(circle, rgba(255,68,68,0.1) 0%, transparent 70%);
        border-radius: 50%;
        font-size: 6rem;
      ">
        🔫
      </div>
    `;
    
    // Simulate spinning with CSS animation
    const fallbackRevolver = this.container.firstElementChild;
    let rotation = 0;
    
    this.spinRevolver = (duration = 3000) => {
      return new Promise((resolve) => {
        const totalRotation = 1440 + Math.random() * 720; // 4-6 full rotations
        const startTime = Date.now();
        
        const animate = () => {
          const elapsed = Date.now() - startTime;
          const progress = Math.min(elapsed / duration, 1);
          const easeOut = 1 - Math.pow(1 - progress, 4);
          
          rotation = totalRotation * easeOut;
          fallbackRevolver.style.transform = `rotate(${rotation}deg)`;
          
          if (progress < 1) {
            requestAnimationFrame(animate);
          } else {
            resolve();
          }
        };
        
        animate();
      });
    };
    
    // Stub other methods
    this.fireBullet = () => Promise.resolve();
    this.highlightChamber = () => {};
    this.resetChambers = () => {};
    this.dispose = () => {};
  }
  
  dispose() {
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
    }
    
    if (this.renderer) {
      this.renderer.dispose();
      if (this.container && this.renderer.domElement) {
        this.container.removeChild(this.renderer.domElement);
      }
    }
    
    // Clean up geometries and materials
    if (this.scene) {
      this.scene.traverse((object) => {
        if (object.geometry) {
          object.geometry.dispose();
        }
        if (object.material) {
          if (Array.isArray(object.material)) {
            object.material.forEach(material => material.dispose());
          } else {
            object.material.dispose();
          }
        }
      });
    }
    
    window.removeEventListener('resize', this.handleResize);
    Logger.log('RevolverRenderer disposed');
  }
}

// Character Sprite Manager (2D-in-3D style animations)
class CharacterSprite {
  constructor(elementId) {
    this.element = document.getElementById(elementId);
    this.isAnimating = false;
    this.animationQueue = [];
    
    if (!this.element) {
      Logger.warn(`CharacterSprite: Element ${elementId} not found`);
    }
  }
  
  async playAnimation(animationType, duration = 1000) {
    if (!this.element) return Promise.resolve();
    
    return new Promise((resolve) => {
      // Add to queue if already animating
      if (this.isAnimating) {
        this.animationQueue.push({ animationType, duration, resolve });
        return;
      }
      
      this.isAnimating = true;
      this.element.classList.add(`character-${animationType}`);
      
      const cleanup = () => {
        if (this.element) {
          this.element.classList.remove(`character-${animationType}`);
        }
        this.isAnimating = false;
        resolve();
        
        // Process queue
        if (this.animationQueue.length > 0) {
          const next = this.animationQueue.shift();
          this.playAnimation(next.animationType, next.duration).then(next.resolve);
        }
      };
      
      setTimeout(cleanup, duration);
    });
  }
  
  setActive(active) {
    if (!this.element) return;
    
    if (active) {
      this.element.classList.add('active');
    } else {
      this.element.classList.remove('active');
    }
  }
  
  updateHealth(percentage) {
    if (!this.element) return;
    
    const healthBar = this.element.querySelector('.health-fill');
    const healthText = this.element.querySelector('.health-text');
    
    if (healthBar) {
      const clampedPercentage = Math.max(0, Math.min(100, percentage));
      healthBar.style.width = `${clampedPercentage}%`;
      
      // Color based on health
      if (clampedPercentage > 60) {
        healthBar.style.backgroundColor = '#48bb78'; // Green
      } else if (clampedPercentage > 30) {
        healthBar.style.backgroundColor = '#ed8936'; // Orange
      } else {
        healthBar.style.backgroundColor = '#ff4444'; // Red
      }
    }
    
    if (healthText) {
      healthText.textContent = `${Math.round(percentage)}%`;
    }
  }
  
  async celebrate() {
    return this.playAnimation('celebrate', 1500);
  }
  
  async takeDamage() {
    return this.playAnimation('hit', 600);
  }
  
  async die() {
    return this.playAnimation('death', 1200);
  }
  
  async fire() {
    return this.playAnimation('firing', 500);
  }
}

// Particle Effect Manager
class ParticleEffectManager {
  constructor(scene) {
    this.scene = scene;
    this.effects = [];
  }
  
  createBloodSpatter(position) {
    if (!window.threeJsAvailable) return;
    
    const particleCount = 20;
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const velocities = new Float32Array(particleCount * 3);
    
    for (let i = 0; i < particleCount; i++) {
      const i3 = i * 3;
      positions[i3] = position.x + (Math.random() - 0.5) * 0.5;
      positions[i3 + 1] = position.y + (Math.random() - 0.5) * 0.5;
      positions[i3 + 2] = position.z + (Math.random() - 0.5) * 0.5;
      
      velocities[i3] = (Math.random() - 0.5) * 2;
      velocities[i3 + 1] = Math.random() * 2;
      velocities[i3 + 2] = (Math.random() - 0.5) * 2;
    }
    
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    
    const material = new THREE.PointsMaterial({
      color: 0x8B0000,
      size: 0.05,
      transparent: true,
      opacity: 0.8
    });
    
    const particles = new THREE.Points(geometry, material);
    this.scene.add(particles);
    
    // Animate particles
    let time = 0;
    const animate = () => {
      time += 0.016; // ~60fps
      
      const positions = particles.geometry.attributes.position.array;
      
      for (let i = 0; i < particleCount; i++) {
        const i3 = i * 3;
        positions[i3] += velocities[i3] * 0.016;
        positions[i3 + 1] += velocities[i3 + 1] * 0.016 - 9.81 * time * time * 0.5; // Gravity
        positions[i3 + 2] += velocities[i3 + 2] * 0.016;
      }
      
      particles.geometry.attributes.position.needsUpdate = true;
      material.opacity = Math.max(0, 0.8 - time * 2);
      
      if (material.opacity > 0) {
        requestAnimationFrame(animate);
      } else {
        this.scene.remove(particles);
        geometry.dispose();
        material.dispose();
      }
    };
    
    animate();
  }
  
  createExplosion(position, color = 0xff4444) {
    if (!window.threeJsAvailable) return;
    
    // Create multiple rings of particles
    for (let ring = 0; ring < 3; ring++) {
      this.createExplosionRing(position, color, ring * 0.1);
    }
  }
  
  createExplosionRing(position, color, delay) {
    setTimeout(() => {
      const particleCount = 30;
      const geometry = new THREE.BufferGeometry();
      const positions = new Float32Array(particleCount * 3);
      const velocities = new Float32Array(particleCount * 3);
      
      for (let i = 0; i < particleCount; i++) {
        const angle = (i / particleCount) * Math.PI * 2;
        const speed = 3 + Math.random() * 2;
        
        const i3 = i * 3;
        positions[i3] = position.x;
        positions[i3 + 1] = position.y;
        positions[i3 + 2] = position.z;
        
        velocities[i3] = Math.cos(angle) * speed;
        velocities[i3 + 1] = (Math.random() - 0.5) * speed;
        velocities[i3 + 2] = Math.sin(angle) * speed;
      }
      
      geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      
      const material = new THREE.PointsMaterial({
        color: color,
        size: 0.1,
        transparent: true,
        opacity: 1.0
      });
      
      const particles = new THREE.Points(geometry, material);
      this.scene.add(particles);
      
      // Animate explosion
      let time = 0;
      const animate = () => {
        time += 0.016;
        
        const positions = particles.geometry.attributes.position.array;
        
        for (let i = 0; i < particleCount; i++) {
          const i3 = i * 3;
          positions[i3] += velocities[i3] * 0.016;
          positions[i3 + 1] += velocities[i3 + 1] * 0.016;
          positions[i3 + 2] += velocities[i3 + 2] * 0.016;
          
          // Slow down particles
          velocities[i3] *= 0.98;
          velocities[i3 + 1] *= 0.98;
          velocities[i3 + 2] *= 0.98;
        }
        
        particles.geometry.attributes.position.needsUpdate = true;
        material.opacity = Math.max(0, 1.0 - time * 1.5);
        
        if (material.opacity > 0) {
          requestAnimationFrame(animate);
        } else {
          this.scene.remove(particles);
          geometry.dispose();
          material.dispose();
        }
      };
      
      animate();
    }, delay * 1000);
  }
  
  dispose() {
    this.effects.forEach(effect => {
      if (effect.geometry) effect.geometry.dispose();
      if (effect.material) effect.material.dispose();
      if (this.scene && effect) this.scene.remove(effect);
    });
    this.effects = [];
  }
}

// Export classes to window object
if (typeof window !== 'undefined') {
  window.RevolverRenderer = RevolverRenderer;
  window.CharacterSprite = CharacterSprite;
  window.ParticleEffectManager = ParticleEffectManager;
  
  Logger.log('Three.js engine module loaded');
}
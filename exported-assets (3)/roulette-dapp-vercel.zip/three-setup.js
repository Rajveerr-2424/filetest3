// Three.js setup and 3D components for Russian Roulette DApp

class RevolverRenderer {
  constructor(containerId) {
    this.containerId = containerId;
    this.container = document.getElementById(containerId);
    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.revolver = null;
    this.muzzleFlash = null;
    this.animationId = null;
    this.isSpinning = false;
    this.currentChamber = 0;
    
    this.init();
  }

  init() {
    if (!this.container) {
      console.error(`Container with id ${this.containerId} not found`);
      return;
    }

    // Scene setup
    this.scene = new THREE.Scene();
    this.scene.background = null; // Transparent background

    // Camera setup (orthographic for 2D-in-3D style)
    const aspect = this.container.clientWidth / this.container.clientHeight;
    const frustumSize = 5;
    this.camera = new THREE.OrthographicCamera(
      frustumSize * aspect / -2,
      frustumSize * aspect / 2,
      frustumSize / 2,
      frustumSize / -2,
      0.1,
      1000
    );
    this.camera.position.set(0, 0, 5);
    this.camera.lookAt(0, 0, 0);

    // Renderer setup
    this.renderer = new THREE.WebGLRenderer({ 
      antialias: true, 
      alpha: true,
      powerPreference: 'high-performance'
    });
    this.renderer.setSize(this.container.clientWidth, this.container.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    
    this.container.appendChild(this.renderer.domElement);

    // Lighting
    this.setupLighting();

    // Create revolver
    this.createRevolver();

    // Start render loop
    this.animate();

    // Handle resize
    window.addEventListener('resize', () => this.handleResize());
  }

  setupLighting() {
    // Ambient light
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    this.scene.add(ambientLight);

    // Directional light
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(5, 5, 5);
    directionalLight.castShadow = true;
    directionalLight.shadow.mapSize.width = 1024;
    directionalLight.shadow.mapSize.height = 1024;
    this.scene.add(directionalLight);

    // Point light for dramatic effect
    const pointLight = new THREE.PointLight(0xff4444, 0.5, 10);
    pointLight.position.set(0, 0, 3);
    this.scene.add(pointLight);
  }

  createRevolver() {
    // Create a stylized revolver using basic Three.js geometry
    const revolverGroup = new THREE.Group();

    // Cylinder (main body)
    const cylinderGeometry = new THREE.CylinderGeometry(0.8, 0.8, 0.3, 32);
    const cylinderMaterial = new THREE.MeshPhongMaterial({ 
      color: 0x444444,
      shininess: 100
    });
    const cylinder = new THREE.Mesh(cylinderGeometry, cylinderMaterial);
    cylinder.rotation.x = Math.PI / 2;
    cylinder.castShadow = true;
    cylinder.receiveShadow = true;
    revolverGroup.add(cylinder);

    // Barrel
    const barrelGeometry = new THREE.CylinderGeometry(0.15, 0.15, 2, 16);
    const barrelMaterial = new THREE.MeshPhongMaterial({ 
      color: 0x333333,
      shininess: 80
    });
    const barrel = new THREE.Mesh(barrelGeometry, barrelMaterial);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.z = 1;
    barrel.castShadow = true;
    revolverGroup.add(barrel);

    // Handle
    const handleGeometry = new THREE.BoxGeometry(0.3, 1.2, 0.2);
    const handleMaterial = new THREE.MeshPhongMaterial({ 
      color: 0x654321,
      shininess: 30
    });
    const handle = new THREE.Mesh(handleGeometry, handleMaterial);
    handle.position.y = -0.8;
    handle.position.z = -0.2;
    handle.castShadow = true;
    revolverGroup.add(handle);

    // Chamber indicators
    const chambers = [];
    for (let i = 0; i < 6; i++) {
      const chamberGeometry = new THREE.CylinderGeometry(0.08, 0.08, 0.1, 8);
      const chamberMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x666666,
        shininess: 50
      });
      const chamber = new THREE.Mesh(chamberGeometry, chamberMaterial);
      
      const angle = (i / 6) * Math.PI * 2;
      chamber.position.x = Math.cos(angle) * 0.5;
      chamber.position.y = Math.sin(angle) * 0.5;
      chamber.position.z = 0.2;
      chamber.rotation.x = Math.PI / 2;
      
      chambers.push(chamber);
      revolverGroup.add(chamber);
    }

    this.chambers = chambers;
    this.revolver = revolverGroup;
    this.scene.add(revolverGroup);

    // Create muzzle flash (initially hidden)
    this.createMuzzleFlash();
  }

  createMuzzleFlash() {
    const flashGroup = new THREE.Group();
    
    // Main flash
    const flashGeometry = new THREE.ConeGeometry(0.5, 1, 8);
    const flashMaterial = new THREE.MeshBasicMaterial({ 
      color: 0xffff00,
      transparent: true,
      opacity: 0
    });
    const flash = new THREE.Mesh(flashGeometry, flashMaterial);
    flash.rotation.x = Math.PI / 2;
    flash.position.z = 2.5;
    flashGroup.add(flash);
    
    // Particles
    const particleGeometry = new THREE.BufferGeometry();
    const particleCount = 20;
    const positions = new Float32Array(particleCount * 3);
    
    for (let i = 0; i < particleCount * 3; i++) {
      positions[i] = (Math.random() - 0.5) * 2;
    }
    
    particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    
    const particleMaterial = new THREE.PointsMaterial({
      color: 0xff6600,
      size: 0.1,
      transparent: true,
      opacity: 0
    });
    
    const particles = new THREE.Points(particleGeometry, particleMaterial);
    particles.position.z = 2.5;
    flashGroup.add(particles);
    
    this.muzzleFlash = flashGroup;
    this.scene.add(flashGroup);
  }

  async spinRevolver(duration = 2000) {
    if (this.isSpinning) return;
    
    this.isSpinning = true;
    
    return new Promise((resolve) => {
      const startRotation = this.revolver.rotation.z;
      const totalRotation = Math.PI * 4 + (Math.random() * Math.PI * 2); // 2+ full rotations
      const startTime = Date.now();
      
      const spin = () => {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        // Easing function for realistic spin
        const easeOut = 1 - Math.pow(1 - progress, 3);
        
        this.revolver.rotation.z = startRotation + (totalRotation * easeOut);
        
        if (progress < 1) {
          requestAnimationFrame(spin);
        } else {
          this.isSpinning = false;
          resolve();
        }
      };
      
      spin();
    });
  }

  async fireBullet(chamber) {
    // Update chamber visual
    if (this.chambers[chamber]) {
      this.chambers[chamber].material.color.setHex(0xff4444);
    }

    // Show muzzle flash
    return new Promise((resolve) => {
      const flashMesh = this.muzzleFlash.children[0];
      const particles = this.muzzleFlash.children[1];
      
      // Flash animation
      if (flashMesh && particles) {
        flashMesh.material.opacity = 1;
        particles.material.opacity = 1;
        
        // Scale animation
        const startScale = 0.5;
        const endScale = 1.5;
        const startTime = Date.now();
        const duration = 500;
        
        const animate = () => {
          const elapsed = Date.now() - startTime;
          const progress = Math.min(elapsed / duration, 1);
          
          const scale = startScale + (endScale - startScale) * progress;
          const opacity = 1 - progress;
          
          flashMesh.scale.set(scale, scale, scale);
          flashMesh.material.opacity = opacity;
          particles.material.opacity = opacity;
          
          if (progress < 1) {
            requestAnimationFrame(animate);
          } else {
            flashMesh.material.opacity = 0;
            particles.material.opacity = 0;
            flashMesh.scale.set(1, 1, 1);
            resolve();
          }
        };
        
        animate();
      } else {
        resolve();
      }
    });
  }

  resetChambers() {
    if (this.chambers) {
      this.chambers.forEach(chamber => {
        chamber.material.color.setHex(0x666666);
      });
    }
  }

  highlightChamber(index) {
    this.resetChambers();
    if (this.chambers[index]) {
      this.chambers[index].material.color.setHex(0xffff00);
    }
  }

  animate() {
    this.animationId = requestAnimationFrame(() => this.animate());
    
    // Subtle idle rotation
    if (!this.isSpinning && this.revolver) {
      this.revolver.rotation.z += 0.005;
    }
    
    this.renderer.render(this.scene, this.camera);
  }

  handleResize() {
    if (!this.container || !this.camera || !this.renderer) return;
    
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    
    // Update camera
    const aspect = width / height;
    const frustumSize = 5;
    this.camera.left = frustumSize * aspect / -2;
    this.camera.right = frustumSize * aspect / 2;
    this.camera.top = frustumSize / 2;
    this.camera.bottom = frustumSize / -2;
    this.camera.updateProjectionMatrix();
    
    // Update renderer
    this.renderer.setSize(width, height);
  }

  dispose() {
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
    }
    
    if (this.renderer) {
      this.renderer.dispose();
    }
    
    window.removeEventListener('resize', this.handleResize);
  }
}

// Character sprite manager for 2D-in-3D style animations
class CharacterSprite {
  constructor(elementId) {
    this.element = document.getElementById(elementId);
    this.isAnimating = false;
  }

  async playAnimation(animationType, duration = 1000) {
    if (!this.element || this.isAnimating) return;
    
    this.isAnimating = true;
    
    return new Promise((resolve) => {
      this.element.classList.add(animationType);
      
      setTimeout(() => {
        if (this.element) {
          this.element.classList.remove(animationType);
        }
        this.isAnimating = false;
        resolve();
      }, duration);
    });
  }

  setActive(active) {
    if (!this.element) return;
    
    if (active) {
      this.element.classList.add('active');
    } else {
      this.element.classList.remove('active');
    }
  }

  updateHealth(percentage) {
    if (!this.element) return;
    
    const healthBar = this.element.querySelector('.health-fill');
    if (healthBar) {
      healthBar.style.width = `${Math.max(0, Math.min(100, percentage))}%`;
    }
  }
}

// Export for use in main app
if (typeof window !== 'undefined') {
  window.RevolverRenderer = RevolverRenderer;
  window.CharacterSprite = CharacterSprite;
}
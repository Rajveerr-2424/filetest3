// Utility functions for the Russian Roulette DApp

// Game configuration
const GAME_CONFIG = {
  revolver: {
    chambers: 6,
    live_bullets: 1,
    animation_duration: 2000
  },
  scoring: {
    death_penalty: -10,
    streak_bonus: 20,
    streak_target: 3
  },
  sounds: {
    spin: { volume: 0.7 },
    gunshot: { volume: 0.8 },
    death: { volume: 0.6 },
    victory: { volume: 0.8 },
    achievement: { volume: 0.9 }
  },
  achievements: [
    {
      name: "First Blood",
      description: "Win your first round",
      points: 5,
      condition: (stats) => stats.wins >= 1
    },
    {
      name: "Lucky Streak",
      description: "Survive 3 consecutive rounds",
      points: 20,
      condition: (stats) => stats.currentStreak >= 3
    },
    {
      name: "Fearless",
      description: "Fire at yourself 10 times",
      points: 15,
      condition: (stats) => stats.selfShots >= 10
    },
    {
      name: "Marksman",
      description: "Eliminate the bot 10 times",
      points: 15,
      condition: (stats) => stats.botKills >= 10
    }
  ]
};

// Game states
const GAME_STATES = {
  CONNECTING_WALLET: 'connecting_wallet',
  INITIALIZING: 'initializing',
  WAITING_FOR_CHOICE: 'waiting_for_choice',
  SPINNING_REVOLVER: 'spinning_revolver',
  FIRING: 'firing',
  SHOWING_RESULT: 'showing_result',
  UPDATING_SCORE: 'updating_score'
};

// Player actions
const PLAYER_ACTIONS = {
  FIRE_AT_SELF: 'fire_at_self',
  FIRE_AT_BOT: 'fire_at_bot'
};

// Sound management
class SoundManager {
  constructor() {
    this.sounds = {};
    this.enabled = true;
    this.init();
  }

  init() {
    // Initialize sound elements
    const soundIds = ['spinSound', 'gunshotSound', 'victorySound', 'deathSound', 'achievementSound'];
    
    soundIds.forEach(id => {
      const element = document.getElementById(id);
      if (element) {
        const soundName = id.replace('Sound', '');
        this.sounds[soundName] = element;
        
        // Set volume based on config
        const config = GAME_CONFIG.sounds[soundName];
        if (config) {
          element.volume = config.volume;
        }
      }
    });
  }

  play(soundName) {
    if (!this.enabled || !this.sounds[soundName]) return;
    
    try {
      this.sounds[soundName].currentTime = 0;
      this.sounds[soundName].play().catch(e => {
        console.warn(`Could not play sound ${soundName}:`, e);
      });
    } catch (error) {
      console.warn(`Error playing sound ${soundName}:`, error);
    }
  }

  setEnabled(enabled) {
    this.enabled = enabled;
  }
}

// Animation utilities
class AnimationManager {
  constructor() {
    this.activeAnimations = new Set();
  }

  animate(element, className, duration = 1000) {
    return new Promise((resolve) => {
      if (!element) {
        resolve();
        return;
      }

      const animationId = `${element.id || 'element'}-${className}-${Date.now()}`;
      this.activeAnimations.add(animationId);
      
      element.classList.add(className);
      
      const cleanup = () => {
        element.classList.remove(className);
        this.activeAnimations.delete(animationId);
        resolve();
      };
      
      setTimeout(cleanup, duration);
    });
  }

  stopAll() {
    this.activeAnimations.clear();
  }
}

// Wallet simulation (since we can't use real Web3 in this environment)
class MockWallet {
  constructor() {
    this.connected = false;
    this.address = null;
    this.network = 'Filecoin Testnet';
  }

  async connect() {
    return new Promise((resolve) => {
      setTimeout(() => {
        this.connected = true;
        this.address = '0x' + Math.random().toString(16).substr(2, 40);
        resolve({
          address: this.address,
          network: this.network
        });
      }, 1500);
    });
  }

  async disconnect() {
    this.connected = false;
    this.address = null;
  }

  isConnected() {
    return this.connected;
  }

  getAddress() {
    return this.address;
  }
}

// Random number generation (simulates blockchain randomness)
class RandomGenerator {
  constructor() {
    this.seed = Date.now();
  }

  // Simulate blockchain VRF (Verifiable Random Function)
  async generateSecureRandom(min = 0, max = 5) {
    return new Promise((resolve) => {
      // Simulate network delay for blockchain call
      setTimeout(() => {
        const random = Math.floor(Math.random() * (max - min + 1)) + min;
        resolve(random);
      }, 1000 + Math.random() * 1000); // 1-2 second delay
    });
  }

  // Quick random for UI effects
  quickRandom(min = 0, max = 5) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
}

// Achievement system
class AchievementManager {
  constructor() {
    this.unlockedAchievements = new Set();
    this.onAchievementUnlocked = null;
  }

  checkAchievements(stats) {
    GAME_CONFIG.achievements.forEach(achievement => {
      if (!this.unlockedAchievements.has(achievement.name) && achievement.condition(stats)) {
        this.unlockAchievement(achievement);
      }
    });
  }

  unlockAchievement(achievement) {
    this.unlockedAchievements.add(achievement.name);
    
    if (this.onAchievementUnlocked) {
      this.onAchievementUnlocked(achievement);
    }
    
    this.showAchievementPopup(achievement);
  }

  showAchievementPopup(achievement) {
    const popup = document.getElementById('achievementPopup');
    const nameElement = document.getElementById('achievementName');
    const pointsElement = document.getElementById('achievementPoints');
    
    if (popup && nameElement && pointsElement) {
      nameElement.textContent = achievement.name;
      pointsElement.textContent = `+${achievement.points} points`;
      
      popup.classList.add('show');
      
      // Hide after 3 seconds
      setTimeout(() => {
        popup.classList.remove('show');
      }, 3000);
    }
  }

  getUnlockedAchievements() {
    return Array.from(this.unlockedAchievements);
  }
}

// Game statistics tracking
class GameStats {
  constructor() {
    this.reset();
  }

  reset() {
    this.score = 0;
    this.currentStreak = 0;
    this.bestStreak = 0;
    this.totalRounds = 0;
    this.wins = 0;
    this.losses = 0;
    this.selfShots = 0;
    this.botShots = 0;
    this.botKills = 0;
    this.deaths = 0;
  }

  updateScore(change, reason = '') {
    this.score += change;
    if (this.score < 0) this.score = 0;
    
    console.log(`Score updated: ${change > 0 ? '+' : ''}${change} (${reason})`);
    return this.score;
  }

  incrementStreak() {
    this.currentStreak++;
    if (this.currentStreak > this.bestStreak) {
      this.bestStreak = this.currentStreak;
    }
    
    // Streak bonus
    if (this.currentStreak >= GAME_CONFIG.scoring.streak_target) {
      this.updateScore(GAME_CONFIG.scoring.streak_bonus, 'streak bonus');
      this.currentStreak = 0; // Reset after bonus
    }
  }

  breakStreak() {
    this.currentStreak = 0;
  }

  recordAction(action, survived, killedBot = false) {
    this.totalRounds++;
    
    if (action === PLAYER_ACTIONS.FIRE_AT_SELF) {
      this.selfShots++;
    } else {
      this.botShots++;
    }
    
    if (survived) {
      this.wins++;
      this.incrementStreak();
      
      if (killedBot) {
        this.botKills++;
      }
    } else {
      this.losses++;
      this.deaths++;
      this.breakStreak();
      this.updateScore(GAME_CONFIG.scoring.death_penalty, 'death penalty');
    }
  }

  getStats() {
    return {
      score: this.score,
      currentStreak: this.currentStreak,
      bestStreak: this.bestStreak,
      totalRounds: this.totalRounds,
      wins: this.wins,
      losses: this.losses,
      selfShots: this.selfShots,
      botShots: this.botShots,
      botKills: this.botKills,
      deaths: this.deaths,
      winRate: this.totalRounds > 0 ? (this.wins / this.totalRounds * 100).toFixed(1) : 0
    };
  }
}

// DOM utilities
class DOMUtils {
  static showScreen(screenId) {
    // Hide all screens
    document.querySelectorAll('.screen').forEach(screen => {
      screen.classList.remove('active');
    });
    
    // Show target screen
    const targetScreen = document.getElementById(screenId);
    if (targetScreen) {
      targetScreen.classList.add('active');
    }
  }

  static updateElement(elementId, content, isHTML = false) {
    const element = document.getElementById(elementId);
    if (element) {
      if (isHTML) {
        element.innerHTML = content;
      } else {
        element.textContent = content;
      }
    }
  }

  static setElementClass(elementId, className, add = true) {
    const element = document.getElementById(elementId);
    if (element) {
      if (add) {
        element.classList.add(className);
      } else {
        element.classList.remove(className);
      }
    }
  }

  static showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.add('show');
    }
  }

  static hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.remove('show');
    }
  }

  static showLoading(text = 'Loading...') {
    const loadingScreen = document.getElementById('loadingScreen');
    const loadingText = document.getElementById('loadingText');
    
    if (loadingScreen) {
      loadingScreen.style.display = 'flex';
    }
    
    if (loadingText) {
      loadingText.textContent = text;
    }
  }

  static hideLoading() {
    const loadingScreen = document.getElementById('loadingScreen');
    if (loadingScreen) {
      loadingScreen.style.display = 'none';
    }
  }
}

// Export utilities for use in other files
if (typeof window !== 'undefined') {
  window.GAME_CONFIG = GAME_CONFIG;
  window.GAME_STATES = GAME_STATES;
  window.PLAYER_ACTIONS = PLAYER_ACTIONS;
  window.SoundManager = SoundManager;
  window.AnimationManager = AnimationManager;
  window.MockWallet = MockWallet;
  window.RandomGenerator = RandomGenerator;
  window.AchievementManager = AchievementManager;
  window.GameStats = GameStats;
  window.DOMUtils = DOMUtils;
}
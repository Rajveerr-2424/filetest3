// Russian Roulette DApp - Utility Functions & Game Logic
// Comprehensive utility system for blockchain Russian Roulette

// Game Configuration
const GAME_CONFIG = {
  revolver: {
    chambers: 6,
    liveBullets: 1,
    spinDuration: 3000,
    fireDuration: 500
  },
  scoring: {
    deathPenalty: -10,
    survivalBonus: 5,
    killBonus: 15,
    streakBonus: 20,
    streakTarget: 3
  },
  blockchain: {
    chainId: 314159,
    networkName: 'Filecoin Calibration',
    currency: 'tFIL',
    explorer: 'https://calibration.filscan.io',
    rpcUrl: 'https://api.calibration.node.glif.io/rpc/v1'
  },
  sounds: {
    spin: { volume: 0.7, duration: 2000 },
    gunshot: { volume: 0.8, duration: 500 },
    death: { volume: 0.6, duration: 2000 },
    victory: { volume: 0.8, duration: 1500 },
    achievement: { volume: 0.9, duration: 1000 }
  },
  achievements: [
    {
      id: 'first_blood',
      name: 'First Blood',
      description: 'Win your first round',
      icon: '🩸',
      points: 5,
      rarity: 'common',
      condition: (stats) => stats.wins >= 1
    },
    {
      id: 'lucky_streak',
      name: 'Lucky Streak',
      description: 'Survive 3 consecutive rounds',
      icon: '🍀',
      points: 20,
      rarity: 'rare',
      condition: (stats) => stats.currentStreak >= 3
    },
    {
      id: 'fearless',
      name: 'Fearless',
      description: 'Fire at yourself 10 times',
      icon: '😤',
      points: 15,
      rarity: 'uncommon',
      condition: (stats) => stats.selfShots >= 10
    },
    {
      id: 'marksman',
      name: 'Marksman',
      description: 'Eliminate the bot 10 times',
      icon: '🎯',
      points: 15,
      rarity: 'uncommon',
      condition: (stats) => stats.botKills >= 10
    },
    {
      id: 'high_roller',
      name: 'High Roller',
      description: 'Reach 100 total points',
      icon: '💎',
      points: 50,
      rarity: 'legendary',
      condition: (stats) => stats.score >= 100
    },
    {
      id: 'survivor',
      name: 'Survivor',
      description: 'Play 50 rounds',
      icon: '🛡️',
      points: 25,
      rarity: 'rare',
      condition: (stats) => stats.totalRounds >= 50
    }
  ]
};

// Game States
const GAME_STATES = {
  DISCONNECTED: 'disconnected',
  CONNECTING_WALLET: 'connecting_wallet',
  WALLET_CONNECTED: 'wallet_connected',
  INITIALIZING_GAME: 'initializing_game',
  WAITING_FOR_CHOICE: 'waiting_for_choice',
  SPINNING_REVOLVER: 'spinning_revolver',
  FIRING: 'firing',
  SHOWING_RESULT: 'showing_result',
  UPDATING_SCORE: 'updating_score',
  ROUND_COMPLETE: 'round_complete'
};

// Player Actions
const PLAYER_ACTIONS = {
  FIRE_AT_SELF: 'fire_at_self',
  FIRE_AT_BOT: 'fire_at_bot'
};

// Sound Manager Class
class SoundManager {
  constructor() {
    this.sounds = {};
    this.enabled = true;
    this.volume = 0.7;
    this.init();
  }

  init() {
    const soundIds = {
      spin: 'spinSound',
      gunshot: 'gunshotSound',
      victory: 'victorySound',
      death: 'deathSound',
      achievement: 'achievementSound'
    };

    Object.entries(soundIds).forEach(([key, id]) => {
      const element = document.getElementById(id);
      if (element) {
        this.sounds[key] = element;
        const config = GAME_CONFIG.sounds[key];
        if (config) {
          element.volume = config.volume * this.volume;
        }
      }
    });

    console.log('SoundManager initialized with', Object.keys(this.sounds).length, 'sounds');
  }

  play(soundName, options = {}) {
    if (!this.enabled || !this.sounds[soundName]) {
      return Promise.resolve();
    }

    return new Promise((resolve) => {
      try {
        const sound = this.sounds[soundName];
        sound.currentTime = 0;
        
        const playPromise = sound.play();
        if (playPromise) {
          playPromise
            .then(() => {
              const duration = options.duration || GAME_CONFIG.sounds[soundName]?.duration || 1000;
              setTimeout(resolve, duration);
            })
            .catch((error) => {
              console.warn(`Could not play sound ${soundName}:`, error);
              resolve();
            });
        } else {
          resolve();
        }
      } catch (error) {
        console.warn(`Error playing sound ${soundName}:`, error);
        resolve();
      }
    });
  }

  setEnabled(enabled) {
    this.enabled = enabled;
    console.log('Sound', enabled ? 'enabled' : 'disabled');
  }

  setVolume(volume) {
    this.volume = Math.max(0, Math.min(1, volume));
    Object.entries(this.sounds).forEach(([key, sound]) => {
      const config = GAME_CONFIG.sounds[key];
      if (config && sound) {
        sound.volume = config.volume * this.volume;
      }
    });
  }

  toggle() {
    this.setEnabled(!this.enabled);
    return this.enabled;
  }
}

// Animation Manager Class
class AnimationManager {
  constructor() {
    this.activeAnimations = new Map();
    this.gsapAvailable = typeof gsap !== 'undefined';
    console.log('AnimationManager initialized, GSAP available:', this.gsapAvailable);
  }

  animate(element, animation, options = {}) {
    if (!element) {
      return Promise.resolve();
    }

    const animationId = `${element.id || 'element'}-${animation}-${Date.now()}`;
    
    return new Promise((resolve) => {
      // Cancel existing animation on this element
      this.stopAnimation(element.id || element);

      if (this.gsapAvailable && this.gsapAnimations[animation]) {
        // Use GSAP for complex animations
        const tween = this.gsapAnimations[animation](element, options);
        tween.then(resolve);
        this.activeAnimations.set(animationId, tween);
      } else {
        // Fallback to CSS classes
        this.cssAnimate(element, animation, options).then(resolve);
      }
    });
  }

  cssAnimate(element, className, options = {}) {
    const duration = options.duration || 1000;
    
    return new Promise((resolve) => {
      element.classList.add(className);
      
      const cleanup = () => {
        element.classList.remove(className);
        resolve();
      };
      
      setTimeout(cleanup, duration);
    });
  }

  gsapAnimations = {
    fireRecoil: (element, options) => {
      return gsap.timeline()
        .to(element, { x: -10, scale: 0.95, duration: 0.1 })
        .to(element, { x: 5, scale: 1.05, duration: 0.1 })
        .to(element, { x: 0, scale: 1, duration: 0.3, ease: 'elastic.out(1, 0.5)' });
    },
    takeDamage: (element, options) => {
      return gsap.timeline()
        .to(element, { scale: 0.9, filter: 'brightness(1.5)', duration: 0.1 })
        .to(element, { scale: 1.1, filter: 'brightness(0.5) hue-rotate(90deg)', duration: 0.2 })
        .to(element, { scale: 1, filter: 'brightness(1)', duration: 0.3 });
    },
    death: (element, options) => {
      return gsap.timeline()
        .to(element, { 
          scale: 0.6, 
          rotation: -25, 
          opacity: 0.3, 
          duration: 1.2, 
          ease: 'power2.out' 
        });
    },
    celebrate: (element, options) => {
      return gsap.timeline()
        .to(element, { scale: 1.2, duration: 0.2 })
        .to(element, { rotation: 360, duration: 0.5 })
        .to(element, { scale: 1, rotation: 0, duration: 0.3 });
    }
  };

  stopAnimation(elementId) {
    for (const [id, animation] of this.activeAnimations) {
      if (id.startsWith(elementId)) {
        if (animation && animation.kill) {
          animation.kill();
        }
        this.activeAnimations.delete(id);
      }
    }
  }

  stopAll() {
    this.activeAnimations.forEach((animation) => {
      if (animation && animation.kill) {
        animation.kill();
      }
    });
    this.activeAnimations.clear();
  }
}

// Random Number Generator (Blockchain Simulation)
class SecureRandomGenerator {
  constructor() {
    this.entropy = this.generateEntropy();
  }

  generateEntropy() {
    // Simulate blockchain entropy sources
    const timestamp = Date.now();
    const userAgent = navigator.userAgent;
    const random = Math.random();
    
    return btoa(`${timestamp}-${userAgent}-${random}`).slice(0, 32);
  }

  // Simulate VRF (Verifiable Random Function) call to blockchain
  async generateSecureRandom(min = 0, max = 5, options = {}) {
    const networkDelay = options.fastMode ? 500 : 1000 + Math.random() * 1500;
    
    return new Promise((resolve) => {
      setTimeout(() => {
        // Simulate cryptographically secure randomness
        const entropy = this.entropy + Date.now();
        const hash = this.simpleHash(entropy);
        const randomValue = hash % (max - min + 1) + min;
        
        console.log(`VRF generated random: ${randomValue} (range: ${min}-${max})`);
        resolve(randomValue);
      }, networkDelay);
    });
  }

  // Simple hash function for demonstration
  simpleHash(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash);
  }

  // Quick local random for UI effects
  quickRandom(min = 0, max = 5) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
}

// Game Statistics Manager
class GameStats {
  constructor() {
    this.reset();
    this.loadFromStorage();
  }

  reset() {
    this.score = 0;
    this.currentStreak = 0;
    this.bestStreak = 0;
    this.totalRounds = 0;
    this.wins = 0;
    this.losses = 0;
    this.selfShots = 0;
    this.botShots = 0;
    this.botKills = 0;
    this.deaths = 0;
    this.achievements = new Set();
  }

  updateScore(change, reason = '') {
    const oldScore = this.score;
    this.score = Math.max(0, this.score + change);
    
    console.log(`Score: ${oldScore} → ${this.score} (${change > 0 ? '+' : ''}${change}) - ${reason}`);
    this.saveToStorage();
    return this.score;
  }

  recordRound(action, survived, killedBot = false) {
    this.totalRounds++;
    
    // Record action type
    if (action === PLAYER_ACTIONS.FIRE_AT_SELF) {
      this.selfShots++;
    } else {
      this.botShots++;
    }
    
    if (survived) {
      this.wins++;
      this.currentStreak++;
      
      // Update best streak
      if (this.currentStreak > this.bestStreak) {
        this.bestStreak = this.currentStreak;
      }
      
      // Award survival points
      this.updateScore(GAME_CONFIG.scoring.survivalBonus, 'survival');
      
      if (killedBot) {
        this.botKills++;
        this.updateScore(GAME_CONFIG.scoring.killBonus, 'bot elimination');
      }
      
      // Check for streak bonus
      if (this.currentStreak >= GAME_CONFIG.scoring.streakTarget) {
        this.updateScore(GAME_CONFIG.scoring.streakBonus, 'streak bonus');
        this.currentStreak = 0; // Reset after bonus
      }
    } else {
      this.losses++;
      this.deaths++;
      this.currentStreak = 0;
      this.updateScore(GAME_CONFIG.scoring.deathPenalty, 'death penalty');
    }
    
    this.saveToStorage();
  }

  getStats() {
    return {
      score: this.score,
      currentStreak: this.currentStreak,
      bestStreak: this.bestStreak,
      totalRounds: this.totalRounds,
      wins: this.wins,
      losses: this.losses,
      selfShots: this.selfShots,
      botShots: this.botShots,
      botKills: this.botKills,
      deaths: this.deaths,
      winRate: this.totalRounds > 0 ? ((this.wins / this.totalRounds) * 100) : 0,
      achievements: Array.from(this.achievements)
    };
  }

  // Simulate localStorage with variables since localStorage is blocked
  saveToStorage() {
    window.gameStatsData = {
      score: this.score,
      currentStreak: this.currentStreak,
      bestStreak: this.bestStreak,
      totalRounds: this.totalRounds,
      wins: this.wins,
      losses: this.losses,
      selfShots: this.selfShots,
      botShots: this.botShots,
      botKills: this.botKills,
      deaths: this.deaths,
      achievements: Array.from(this.achievements)
    };
  }

  loadFromStorage() {
    const data = window.gameStatsData;
    if (data) {
      Object.assign(this, data);
      this.achievements = new Set(data.achievements || []);
    }
  }
}

// Achievement Manager
class AchievementManager {
  constructor() {
    this.onAchievementUnlocked = null;
    this.checkCooldown = new Set();
  }

  checkAchievements(stats) {
    GAME_CONFIG.achievements.forEach(achievement => {
      if (!stats.achievements.includes(achievement.id) && 
          !this.checkCooldown.has(achievement.id) &&
          achievement.condition(stats)) {
        this.unlockAchievement(achievement, stats);
      }
    });
  }

  unlockAchievement(achievement, stats) {
    console.log(`🏆 Achievement unlocked: ${achievement.name}`);
    
    // Add to cooldown to prevent duplicate checks
    this.checkCooldown.add(achievement.id);
    setTimeout(() => this.checkCooldown.delete(achievement.id), 1000);
    
    // Add to stats
    stats.achievements.push(achievement.id);
    
    // Trigger callback
    if (this.onAchievementUnlocked) {
      this.onAchievementUnlocked(achievement);
    }
    
    // Show achievement modal
    this.showAchievementModal(achievement);
  }

  showAchievementModal(achievement) {
    const modal = document.getElementById('achievementModal');
    const nameEl = document.getElementById('achievementName');
    const descEl = document.getElementById('achievementDesc');
    const pointsEl = document.getElementById('achievementPoints');
    
    if (modal && nameEl && descEl && pointsEl) {
      nameEl.textContent = achievement.name;
      descEl.textContent = achievement.description;
      pointsEl.textContent = `+${achievement.points} points`;
      
      modal.classList.add('show');
      
      // Auto-hide after 4 seconds
      setTimeout(() => {
        modal.classList.remove('show');
      }, 4000);
    }
  }

  getAchievementById(id) {
    return GAME_CONFIG.achievements.find(a => a.id === id);
  }

  getAllAchievements() {
    return GAME_CONFIG.achievements;
  }
}

// DOM Utility Functions
class DOMUtils {
  static showPage(pageId) {
    // Hide all pages
    document.querySelectorAll('.page').forEach(page => {
      page.classList.remove('active');
    });
    
    // Show target page
    const targetPage = document.getElementById(pageId);
    if (targetPage) {
      targetPage.classList.add('active');
    }
    
    // Update navigation
    document.querySelectorAll('.nav-btn').forEach(btn => {
      btn.classList.remove('active');
    });
    
    const navButton = document.getElementById(`nav${pageId.charAt(0).toUpperCase() + pageId.slice(1).replace('Page', '')}`);
    if (navButton) {
      navButton.classList.add('active');
    }
  }

  static updateElement(elementId, content, isHTML = false) {
    const element = document.getElementById(elementId);
    if (element) {
      if (isHTML) {
        element.innerHTML = content;
      } else {
        element.textContent = content;
      }
    }
  }

  static toggleClass(elementId, className, force) {
    const element = document.getElementById(elementId);
    if (element) {
      if (force !== undefined) {
        element.classList.toggle(className, force);
      } else {
        element.classList.toggle(className);
      }
    }
  }

  static showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.add('show');
    }
  }

  static hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.remove('show');
    }
  }

  static showLoading(message = 'Loading...') {
    const loadingScreen = document.getElementById('loadingScreen');
    const loadingText = document.getElementById('loadingText');
    
    if (loadingScreen) {
      loadingScreen.style.display = 'flex';
    }
    
    if (loadingText) {
      loadingText.textContent = message;
    }
  }

  static hideLoading() {
    const loadingScreen = document.getElementById('loadingScreen');
    if (loadingScreen) {
      loadingScreen.style.display = 'none';
    }
  }

  static showTransactionStatus(message) {
    const txStatus = document.getElementById('txStatus');
    const txMessage = document.getElementById('txMessage');
    
    if (txStatus && txMessage) {
      txMessage.textContent = message;
      txStatus.classList.add('show');
    }
  }

  static hideTransactionStatus() {
    const txStatus = document.getElementById('txStatus');
    if (txStatus) {
      txStatus.classList.remove('show');
    }
  }

  static updateNetworkStatus(connected, networkName = 'Unknown') {
    const indicator = document.querySelector('.network-indicator');
    if (indicator) {
      if (connected) {
        indicator.classList.add('connected');
        indicator.querySelector('span').textContent = networkName;
      } else {
        indicator.classList.remove('connected');
        indicator.querySelector('span').textContent = 'Disconnected';
      }
    }
  }
}

// Event Emitter for custom events
class EventEmitter {
  constructor() {
    this.events = {};
  }

  on(event, callback) {
    if (!this.events[event]) {
      this.events[event] = [];
    }
    this.events[event].push(callback);
  }

  emit(event, data) {
    if (this.events[event]) {
      this.events[event].forEach(callback => callback(data));
    }
  }

  off(event, callback) {
    if (this.events[event]) {
      this.events[event] = this.events[event].filter(cb => cb !== callback);
    }
  }
}

// Logger utility
class Logger {
  static log(message, type = 'info', data = null) {
    const timestamp = new Date().toISOString();
    const logMessage = `[${timestamp}] ${type.toUpperCase()}: ${message}`;
    
    console.log(logMessage, data || '');
    
    // Store in memory log (since we can't use localStorage)
    if (!window.gameLogs) window.gameLogs = [];
    window.gameLogs.push({ timestamp, type, message, data });
    
    // Keep only last 100 logs
    if (window.gameLogs.length > 100) {
      window.gameLogs = window.gameLogs.slice(-100);
    }
  }

  static error(message, error = null) {
    this.log(message, 'error', error);
  }

  static warn(message, data = null) {
    this.log(message, 'warn', data);
  }

  static debug(message, data = null) {
    this.log(message, 'debug', data);
  }
}

// Export all utilities to window object
if (typeof window !== 'undefined') {
  window.GAME_CONFIG = GAME_CONFIG;
  window.GAME_STATES = GAME_STATES;
  window.PLAYER_ACTIONS = PLAYER_ACTIONS;
  window.SoundManager = SoundManager;
  window.AnimationManager = AnimationManager;
  window.SecureRandomGenerator = SecureRandomGenerator;
  window.GameStats = GameStats;
  window.AchievementManager = AchievementManager;
  window.DOMUtils = DOMUtils;
  window.EventEmitter = EventEmitter;
  window.Logger = Logger;
  
  Logger.log('Utils module loaded successfully');
}

// Performance monitoring
window.gamePerformance = {
  startTime: Date.now(),
  marks: {},
  
  mark(name) {
    this.marks[name] = Date.now();
  },
  
  measure(name, startMark) {
    if (this.marks[startMark]) {
      const duration = Date.now() - this.marks[startMark];
      Logger.debug(`Performance: ${name} took ${duration}ms`);
      return duration;
    }
    return 0;
  }
};